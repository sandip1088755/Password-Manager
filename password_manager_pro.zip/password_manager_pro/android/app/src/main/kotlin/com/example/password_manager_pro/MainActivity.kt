package com.example.password_manager_pro

import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Settings
import android.view.autofill.AutofillManager
import androidx.annotation.NonNull
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {

    companion object {
        const val CHANNEL = "com.example.password_manager_pro/autofill"
        const val PREFS_FILE = "vault_autofill_prefs"
        const val KEY_SESSION_KEY = "session_key_b64"
    }

    // Encrypted (Android Keystore-backed) prefs — the ONLY place the raw
    // session key lives outside the Dart isolate's memory. Cleared the
    // instant the vault locks.
    private fun encryptedPrefs() = run {
        val masterKey = MasterKey.Builder(applicationContext)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        EncryptedSharedPreferences.create(
            applicationContext,
            PREFS_FILE,
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    override fun configureFlutterEngine(@NonNull flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "setSessionKey" -> {
                        val keyB64 = call.argument<String>("key")
                        if (keyB64 != null) {
                            encryptedPrefs().edit()
                                .putString(KEY_SESSION_KEY, keyB64)
                                .apply()
                        }
                        result.success(null)
                    }

                    "clearSessionKey" -> {
                        encryptedPrefs().edit().remove(KEY_SESSION_KEY).apply()
                        result.success(null)
                    }

                    "isAutofillEnabled" -> {
                        result.success(isThisAppTheAutofillProvider())
                    }

                    "openAutofillSettings" -> {
                        openAutofillSettingsScreen()
                        result.success(null)
                    }

                    else -> result.notImplemented()
                }
            }
    }

    private fun isThisAppTheAutofillProvider(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return false
        val afm = getSystemService(AutofillManager::class.java)
        return afm?.hasEnabledAutofillServices() == true
    }

    private fun openAutofillSettingsScreen() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        try {
            val intent = Intent(Settings.ACTION_REQUEST_SET_AUTOFILL_SERVICE)
            intent.data = android.net.Uri.parse("package:$packageName")
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
            startActivity(intent)
        } catch (e: Exception) {
            // Fall back to the general autofill settings page if the
            // direct-request intent isn't supported on this OEM's build.
            val fallback = Intent(Settings.ACTION_SETTINGS)
            fallback.flags = Intent.FLAG_ACTIVITY_NEW_TASK
            startActivity(fallback)
        }
    }
}
