package com.example.password_manager_pro

import android.app.assist.AssistStructure
import android.database.sqlite.SQLiteDatabase
import android.os.Build
import android.os.CancellationSignal
import android.service.autofill.AutofillService
import android.service.autofill.Dataset
import android.service.autofill.FillCallback
import android.service.autofill.FillRequest
import android.service.autofill.FillResponse
import android.service.autofill.SaveCallback
import android.service.autofill.SaveInfo
import android.service.autofill.SaveRequest
import android.util.Base64
import android.view.View
import android.view.autofill.AutofillId
import android.view.autofill.AutofillValue
import android.widget.RemoteViews
import androidx.annotation.RequiresApi
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import java.io.File
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * System-wide Autofill Service. Android calls onFillRequest() whenever the
 * user focuses a login field in ANY app (Facebook, Instagram, mobile
 * banking, etc) or in Chrome. We inspect the screen's view hierarchy,
 * find username/password fields, match them against vault entries stored
 * in the same SQLite database the Flutter app writes to, decrypt the
 * matching password with the mirrored session key, and hand back
 * suggestions the user taps to fill instantly.
 *
 * Only works while the vault is unlocked in the Flutter app (i.e. a
 * session key has been mirrored into EncryptedSharedPreferences) — the
 * moment the vault locks, this service can no longer decrypt anything.
 */
@RequiresApi(Build.VERSION_CODES.O)
class VaultAutofillService : AutofillService() {

    override fun onFillRequest(
        request: FillRequest,
        cancellationSignal: CancellationSignal,
        callback: FillCallback
    ) {
        val structure = request.fillContexts.lastOrNull()?.structure
        if (structure == null) {
            callback.onSuccess(null)
            return
        }

        val fields = FieldFinder().findLoginFields(structure)
        if (fields.usernameId == null && fields.passwordId == null) {
            callback.onSuccess(null)
            return
        }

        val sessionKey = readSessionKey()
        if (sessionKey == null) {
            // Vault is locked — nothing we can safely offer right now.
            callback.onSuccess(null)
            return
        }

        val searchTerm = buildSearchTerm(structure, fields)
        val entries = queryMatchingEntries(searchTerm)

        if (entries.isEmpty()) {
            callback.onSuccess(null)
            return
        }

        val responseBuilder = FillResponse.Builder()

        for (entry in entries.take(5)) {
            val decryptedPassword = try {
                decryptAesGcm(entry.encryptedPassword, sessionKey)
            } catch (e: Exception) {
                null
            } ?: continue

            val presentation = RemoteViews(packageName, android.R.layout.simple_list_item_1)
            presentation.setTextViewText(
                android.R.id.text1,
                "${entry.title} (${entry.username})"
            )

            val datasetBuilder = Dataset.Builder()
            fields.usernameId?.let {
                datasetBuilder.setValue(
                    it, AutofillValue.forText(entry.username), presentation
                )
            }
            fields.passwordId?.let {
                datasetBuilder.setValue(
                    it, AutofillValue.forText(decryptedPassword), presentation
                )
            }
            responseBuilder.addDataset(datasetBuilder.build())
        }

        // Offer to save new/changed credentials the user types & submits.
        val saveIds = listOfNotNull(fields.usernameId, fields.passwordId).toTypedArray()
        if (saveIds.isNotEmpty()) {
            responseBuilder.setSaveInfo(
                SaveInfo.Builder(SaveInfo.SAVE_DATA_TYPE_PASSWORD, saveIds).build()
            )
        }

        callback.onSuccess(responseBuilder.build())
    }

    override fun onSaveRequest(request: SaveRequest, callback: SaveCallback) {
        val structure = request.fillContexts.lastOrNull()?.structure
        if (structure == null) {
            callback.onFailure("No structure")
            return
        }

        val fields = FieldFinder().findLoginFields(structure)
        val username = fields.usernameValue ?: ""
        val password = fields.passwordValue

        val sessionKey = readSessionKey()
        if (password.isNullOrEmpty() || sessionKey == null) {
            callback.onFailure("Vault locked or no password captured")
            return
        }

        val searchTerm = buildSearchTerm(structure, fields)
        try {
            val encryptedPassword = encryptAesGcm(password, sessionKey)
            insertNewEntry(
                title = searchTerm.ifBlank { "New Login" },
                username = username,
                encryptedPassword = encryptedPassword,
                website = searchTerm
            )
            callback.onSuccess()
        } catch (e: Exception) {
            callback.onFailure(e.message ?: "Save failed")
        }
    }

    // ---------------------------------------------------------------
    // Session key (mirrored from Flutter via MainActivity's MethodChannel)
    // ---------------------------------------------------------------

    private fun readSessionKey(): ByteArray? {
        return try {
            val masterKey = MasterKey.Builder(applicationContext)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build()
            val prefs = EncryptedSharedPreferences.create(
                applicationContext,
                MainActivity.PREFS_FILE,
                masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
            val b64 = prefs.getString(MainActivity.KEY_SESSION_KEY, null) ?: return null
            Base64.decode(b64, Base64.DEFAULT)
        } catch (e: Exception) {
            null
        }
    }

    // ---------------------------------------------------------------
    // AES-256-GCM — must exactly match lib/core/encryption_service.dart:
    // stored string = base64( iv[12 bytes] + ciphertext+tag )
    // ---------------------------------------------------------------

    private fun decryptAesGcm(base64CipherText: String, key: ByteArray): String {
        val combined = Base64.decode(base64CipherText, Base64.DEFAULT)
        val iv = combined.copyOfRange(0, 12)
        val cipherBytes = combined.copyOfRange(12, combined.size)

        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        val keySpec = SecretKeySpec(key, "AES")
        val gcmSpec = GCMParameterSpec(128, iv)
        cipher.init(Cipher.DECRYPT_MODE, keySpec, gcmSpec)
        return String(cipher.doFinal(cipherBytes), Charsets.UTF_8)
    }

    private fun encryptAesGcm(plainText: String, key: ByteArray): String {
        val iv = ByteArray(12)
        java.security.SecureRandom().nextBytes(iv)

        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        val keySpec = SecretKeySpec(key, "AES")
        val gcmSpec = GCMParameterSpec(128, iv)
        cipher.init(Cipher.ENCRYPT_MODE, keySpec, gcmSpec)
        val cipherBytes = cipher.doFinal(plainText.toByteArray(Charsets.UTF_8))

        val combined = iv + cipherBytes
        return Base64.encodeToString(combined, Base64.NO_WRAP)
    }

    // ---------------------------------------------------------------
    // Direct SQLite access — same vault.db the Flutter app writes to,
    // at context.filesDir/vault.db (path_provider's documents directory
    // on Android maps to filesDir).
    // ---------------------------------------------------------------

    private data class VaultRow(
        val title: String,
        val username: String,
        val encryptedPassword: String
    )

    private fun openVaultDb(): SQLiteDatabase? {
        val dbFile = File(applicationContext.filesDir, "vault.db")
        if (!dbFile.exists()) return null
        return SQLiteDatabase.openDatabase(
            dbFile.path, null, SQLiteDatabase.OPEN_READWRITE
        )
    }

    private fun queryMatchingEntries(searchTerm: String): List<VaultRow> {
        if (searchTerm.isBlank()) return emptyList()
        val db = openVaultDb() ?: return emptyList()
        val results = mutableListOf<VaultRow>()
        try {
            val cursor = db.rawQuery(
                "SELECT title, username, encrypted_password, website FROM vault_entries " +
                    "WHERE title LIKE ? OR website LIKE ?",
                arrayOf("%$searchTerm%", "%$searchTerm%")
            )
            cursor.use {
                while (it.moveToNext()) {
                    results.add(
                        VaultRow(
                            title = it.getString(0),
                            username = it.getString(1),
                            encryptedPassword = it.getString(2)
                        )
                    )
                }
            }
        } catch (e: Exception) {
            // Table might not exist yet on a fresh install — ignore.
        } finally {
            db.close()
        }
        return results
    }

    private fun insertNewEntry(
        title: String,
        username: String,
        encryptedPassword: String,
        website: String
    ) {
        val db = openVaultDb() ?: return
        try {
            val now = java.text.SimpleDateFormat(
                "yyyy-MM-dd'T'HH:mm:ss.SSS", java.util.Locale.US
            ).format(java.util.Date())
            db.execSQL(
                "INSERT INTO vault_entries " +
                    "(title, username, encrypted_password, website, category, " +
                    "encrypted_notes, favorite, created_at, updated_at) " +
                    "VALUES (?, ?, ?, ?, 'General', '', 0, ?, ?)",
                arrayOf(title, username, encryptedPassword, website, now, now)
            )
        } finally {
            db.close()
        }
    }

    // ---------------------------------------------------------------
    // Screen parsing — walks the AssistStructure Android hands us to find
    // which fields are the username/password inputs, and derives a
    // search keyword (app package name or web domain) to match against
    // vault entries.
    // ---------------------------------------------------------------

    private data class LoginFields(
        var usernameId: AutofillId? = null,
        var passwordId: AutofillId? = null,
        var usernameValue: String? = null,
        var passwordValue: String? = null,
        var packageName: String? = null,
        var webDomain: String? = null
    )

    private class FieldFinder {
        fun findLoginFields(structure: AssistStructure): LoginFields {
            val result = LoginFields()
            for (i in 0 until structure.windowNodeCount) {
                val windowNode = structure.getWindowNodeAt(i)
                walk(windowNode.rootViewNode, result)
            }
            return result
        }

        private fun walk(node: AssistStructure.ViewNode, result: LoginFields) {
            node.webDomain?.let { if (it.isNotBlank()) result.webDomain = it }

            val hints = node.autofillHints
            val inputType = node.inputType
            val isPasswordField =
                (inputType and android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD != 0) ||
                    (inputType and android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD != 0) ||
                    hints?.any { it == View.AUTOFILL_HINT_PASSWORD } == true

            val isUsernameField =
                hints?.any {
                    it == View.AUTOFILL_HINT_USERNAME ||
                        it == View.AUTOFILL_HINT_EMAIL_ADDRESS
                } == true

            if (isPasswordField && node.autofillId != null) {
                result.passwordId = node.autofillId
                result.passwordValue = node.autofillValue?.let {
                    if (it.isText) it.textValue?.toString() else null
                }
            } else if (isUsernameField && node.autofillId != null) {
                result.usernameId = node.autofillId
                result.usernameValue = node.autofillValue?.let {
                    if (it.isText) it.textValue?.toString() else null
                }
            }

            for (i in 0 until node.childCount) {
                walk(node.getChildAt(i), result)
            }
        }
    }

    private fun buildSearchTerm(structure: AssistStructure, fields: LoginFields): String {
        // Prefer the web domain when present (Chrome/WebView logins),
        // otherwise derive a keyword from the app's package name, e.g.
        // "com.facebook.katana" -> "facebook".
        fields.webDomain?.let { if (it.isNotBlank()) return it }

        val packageName = structure.activityComponent?.packageName ?: ""
        val tokens = packageName
            .split(".", "_")
            .filter { it.length > 3 && it != "com" && it != "android" }
        return tokens.maxByOrNull { it.length } ?: packageName
    }
}
