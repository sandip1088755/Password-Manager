import 'dart:io';

import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';

import '../../services/secure_file_service.dart';

class FileViewerScreen extends StatefulWidget {
  final SecureFileRecord record;

  const FileViewerScreen({super.key, required this.record});

  @override
  State<FileViewerScreen> createState() => _FileViewerScreenState();
}

class _FileViewerScreenState extends State<FileViewerScreen> {
  File? _tempFile;
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _decryptToTemp();
  }

  Future<void> _decryptToTemp() async {
    try {
      final bytes = await SecureFileService.instance
          .decryptFile(widget.record.encryptedFilePath);
      final tempDir = await getTemporaryDirectory();
      final tempFile = File(
          '${tempDir.path}/decrypted_${widget.record.displayName}');
      await tempFile.writeAsBytes(bytes);
      if (!mounted) return;
      setState(() {
        _tempFile = tempFile;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _error = 'Could not decrypt file — vault may be locked.';
        _loading = false;
      });
    }
  }

  @override
  void dispose() {
    // Wipe the decrypted temp copy the moment this screen closes — it
    // should never linger unencrypted on disk longer than needed.
    _tempFile?.delete().catchError((_) => _tempFile!);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.record.displayName)),
      body: SafeArea(
        child: Center(
          child: _loading
              ? const CircularProgressIndicator()
              : _error != null
                  ? Text(_error!, style: const TextStyle(color: Colors.red))
                  : widget.record.fileType == 'image'
                      ? InteractiveViewer(
                          child: Image.file(_tempFile!),
                        )
                      : Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(
                              widget.record.fileType == 'pdf'
                                  ? Icons.picture_as_pdf
                                  : Icons.description,
                              size: 72,
                              color: Theme.of(context).colorScheme.primary,
                            ),
                            const SizedBox(height: 16),
                            Text(widget.record.displayName),
                            const SizedBox(height: 8),
                            const Text(
                              'Preview not supported for this file type in-app.\n'
                              'The file has been decrypted to a temporary '
                              'location for this session only.',
                              textAlign: TextAlign.center,
                              style: TextStyle(color: Colors.grey),
                            ),
                          ],
                        ),
        ),
      ),
    );
  }
}
