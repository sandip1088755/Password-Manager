// password_generator_screen.dart — same generator as before, now wired
// into the app. If opened with returnsResult: true (e.g. from the
// Add/Edit Entry screen), a "Use this password" button appears that pops
// the screen and returns the generated string to the caller via
// Navigator.pop(context, result).

import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

enum GeneratorMode { password, passphrase, pin }

class PasswordGeneratorScreen extends StatefulWidget {
  final bool returnsResult;

  const PasswordGeneratorScreen({super.key, this.returnsResult = false});

  @override
  State<PasswordGeneratorScreen> createState() =>
      _PasswordGeneratorScreenState();
}

class _PasswordGeneratorScreenState extends State<PasswordGeneratorScreen> {
  final Random _secureRandom = Random.secure();

  GeneratorMode _mode = GeneratorMode.password;

  double _length = 16;
  bool _useUpper = true;
  bool _useLower = true;
  bool _useNumbers = true;
  bool _useSymbols = true;
  bool _excludeSimilar = false;
  bool _easyToRead = false;
  bool _easyToSpeak = false;

  double _wordCount = 4;
  String _separator = '-';
  bool _capitalizeWords = true;
  bool _includeNumberInPassphrase = true;

  double _pinLength = 6;

  String _result = '';

  static const String _upperChars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  static const String _lowerChars = 'abcdefghijklmnopqrstuvwxyz';
  static const String _numberChars = '0123456789';
  static const String _symbolChars = r'!@#$%^&*()_+-=[]{}|;:,.<>?';
  static const String _similarChars = 'il1LoO0|';

  static const List<String> _wordList = [
    'orbit', 'maple', 'quartz', 'ember', 'delta', 'harbor', 'lunar', 'pixel',
    'thorn', 'vapor', 'cider', 'flint', 'grove', 'ripple', 'shard', 'ashen',
    'cobalt', 'drift', 'fable', 'glint', 'husk', 'ivory', 'jetty', 'karma',
    'lattice', 'mango', 'niche', 'ozone', 'plume', 'quill', 'raven', 'sable',
    'timber', 'umbra', 'velvet', 'willow', 'xenon', 'yonder', 'zephyr',
    'amber', 'brisk', 'cedar', 'dune', 'ferry', 'granite', 'hollow', 'inlet',
  ];

  static const List<String> _consonants = [
    'b', 'c', 'd', 'f', 'g', 'h', 'j', 'k', 'l', 'm', 'n', 'p', 'r', 's', 't',
    'v', 'w', 'z'
  ];
  static const List<String> _vowels = ['a', 'e', 'i', 'o', 'u'];

  @override
  void initState() {
    super.initState();
    _generate();
  }

  int _secureIndex(int max) => _secureRandom.nextInt(max);

  String _buildCharPool() {
    String pool = '';
    if (_useUpper) pool += _upperChars;
    if (_useLower) pool += _lowerChars;
    if (_useNumbers) pool += _numberChars;
    if (_useSymbols) pool += _symbolChars;

    if (_excludeSimilar || _easyToRead) {
      pool = pool.split('').where((c) => !_similarChars.contains(c)).join();
    }
    return pool;
  }

  void _generate() {
    setState(() {
      switch (_mode) {
        case GeneratorMode.password:
          _result = _easyToSpeak ? _generateSpeakable() : _generatePassword();
          break;
        case GeneratorMode.passphrase:
          _result = _generatePassphrase();
          break;
        case GeneratorMode.pin:
          _result = _generatePin();
          break;
      }
    });
  }

  String _generatePassword() {
    final pool = _buildCharPool();
    if (pool.isEmpty) return 'Select at least one character type';
    final len = _length.round();
    final chars = <String>[];

    final mandatory = <String>[];
    if (_useUpper) mandatory.add(_pick(_stripSimilar(_upperChars)));
    if (_useLower) mandatory.add(_pick(_stripSimilar(_lowerChars)));
    if (_useNumbers) mandatory.add(_pick(_stripSimilar(_numberChars)));
    if (_useSymbols) mandatory.add(_pick(_symbolChars));

    for (var i = 0; i < len; i++) {
      chars.add(_pick(pool));
    }
    for (var i = 0; i < mandatory.length && i < chars.length; i++) {
      chars[i] = mandatory[i];
    }
    chars.shuffle(_secureRandom);
    return chars.join();
  }

  String _stripSimilar(String source) {
    if (!_excludeSimilar && !_easyToRead) return source;
    return source.split('').where((c) => !_similarChars.contains(c)).join();
  }

  String _pick(String pool) => pool[_secureIndex(pool.length)];

  String _generateSpeakable() {
    final len = _length.round().clamp(4, 128);
    final buffer = StringBuffer();
    bool useConsonant = true;
    while (buffer.length < len) {
      buffer.write(useConsonant
          ? _consonants[_secureIndex(_consonants.length)]
          : _vowels[_secureIndex(_vowels.length)]);
      useConsonant = !useConsonant;
    }
    var word = buffer.toString().substring(0, len);
    if (_useUpper) word = word[0].toUpperCase() + word.substring(1);
    if (_useNumbers) word = '$word${_secureIndex(10)}';
    return word;
  }

  String _generatePassphrase() {
    final count = _wordCount.round();
    final words = <String>[];
    for (var i = 0; i < count; i++) {
      var w = _wordList[_secureIndex(_wordList.length)];
      if (_capitalizeWords) w = w[0].toUpperCase() + w.substring(1);
      words.add(w);
    }
    var phrase = words.join(_separator);
    if (_includeNumberInPassphrase) {
      phrase = '$phrase$_separator${_secureIndex(90) + 10}';
    }
    return phrase;
  }

  String _generatePin() {
    final len = _pinLength.round();
    final buffer = StringBuffer();
    for (var i = 0; i < len; i++) {
      buffer.write(_secureIndex(10));
    }
    return buffer.toString();
  }

  double _calculateEntropy() {
    switch (_mode) {
      case GeneratorMode.password:
        if (_easyToSpeak) {
          return _length.round() * (log(18) / log(2));
        }
        final poolSize = _buildCharPool().length;
        if (poolSize == 0) return 0;
        return _length.round() * (log(poolSize) / log(2));
      case GeneratorMode.passphrase:
        final perWord = log(_wordList.length) / log(2);
        return _wordCount.round() * perWord;
      case GeneratorMode.pin:
        return _pinLength.round() * (log(10) / log(2));
    }
  }

  ({String label, Color color, double value}) _strengthInfo(double entropy) {
    if (entropy < 28) return (label: 'Weak', color: Colors.red, value: 0.2);
    if (entropy < 50) return (label: 'Fair', color: Colors.orange, value: 0.45);
    if (entropy < 70) return (label: 'Good', color: Colors.amber, value: 0.65);
    if (entropy < 100) {
      return (label: 'Strong', color: Colors.lightGreen, value: 0.85);
    }
    return (label: 'Very Strong', color: Colors.green, value: 1.0);
  }

  void _copyToClipboard() {
    Clipboard.setData(ClipboardData(text: _result));
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
          content: Text('Copied to clipboard'),
          duration: Duration(seconds: 2)),
    );
  }

  @override
  Widget build(BuildContext context) {
    final entropy = _calculateEntropy();
    final strength = _strengthInfo(entropy);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Password Generator'),
        centerTitle: true,
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            _buildModeSelector(),
            const SizedBox(height: 20),
            _buildResultCard(strength, entropy),
            const SizedBox(height: 24),
            _buildOptionsForMode(),
            const SizedBox(height: 24),
            if (widget.returnsResult) ...[
              FilledButton.icon(
                onPressed: () => Navigator.of(context).pop(_result),
                icon: const Icon(Icons.check),
                label: const Text('Use this password'),
                style: FilledButton.styleFrom(
                  minimumSize: const Size.fromHeight(52),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14),
                  ),
                ),
              ),
              const SizedBox(height: 12),
            ],
            OutlinedButton.icon(
              onPressed: _generate,
              icon: const Icon(Icons.refresh),
              label: const Text('Regenerate'),
              style: OutlinedButton.styleFrom(
                minimumSize: const Size.fromHeight(52),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildModeSelector() {
    return SegmentedButton<GeneratorMode>(
      segments: const [
        ButtonSegment(
            value: GeneratorMode.password,
            label: Text('Password'),
            icon: Icon(Icons.key)),
        ButtonSegment(
            value: GeneratorMode.passphrase,
            label: Text('Passphrase'),
            icon: Icon(Icons.text_fields)),
        ButtonSegment(
            value: GeneratorMode.pin,
            label: Text('PIN'),
            icon: Icon(Icons.pin)),
      ],
      selected: {_mode},
      onSelectionChanged: (selection) {
        setState(() => _mode = selection.first);
        _generate();
      },
    );
  }

  Widget _buildResultCard(
      ({String label, Color color, double value}) strength, double entropy) {
    final scheme = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: scheme.surfaceContainerHighest,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: scheme.outlineVariant),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: SelectableText(
                  _result,
                  style: const TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w600,
                    fontFamily: 'monospace',
                    letterSpacing: 0.5,
                  ),
                ),
              ),
              IconButton(
                icon: const Icon(Icons.copy_rounded),
                tooltip: 'Copy',
                onPressed: _copyToClipboard,
              ),
            ],
          ),
          const SizedBox(height: 16),
          ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: LinearProgressIndicator(
              value: strength.value,
              minHeight: 8,
              backgroundColor: scheme.surfaceContainerHigh,
              color: strength.color,
            ),
          ),
          const SizedBox(height: 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(strength.label,
                  style: TextStyle(
                      color: strength.color, fontWeight: FontWeight.bold)),
              Text('${entropy.toStringAsFixed(1)} bits entropy',
                  style: Theme.of(context).textTheme.bodySmall),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildOptionsForMode() {
    switch (_mode) {
      case GeneratorMode.password:
        return _buildPasswordOptions();
      case GeneratorMode.passphrase:
        return _buildPassphraseOptions();
      case GeneratorMode.pin:
        return _buildPinOptions();
    }
  }

  Widget _buildPasswordOptions() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _sectionTitle('Length: ${_length.round()}'),
        Slider(
          value: _length,
          min: 4,
          max: 128,
          divisions: 124,
          label: _length.round().toString(),
          onChanged: (v) {
            setState(() => _length = v);
            _generate();
          },
        ),
        _sectionTitle('Character Types'),
        _switchTile('Uppercase (A-Z)', _useUpper, (v) {
          setState(() => _useUpper = v);
          _generate();
        }),
        _switchTile('Lowercase (a-z)', _useLower, (v) {
          setState(() => _useLower = v);
          _generate();
        }),
        _switchTile('Numbers (0-9)', _useNumbers, (v) {
          setState(() => _useNumbers = v);
          _generate();
        }),
        _switchTile('Symbols (!@#\$...)', _useSymbols, (v) {
          setState(() => _useSymbols = v);
          _generate();
        }),
        _sectionTitle('Readability'),
        _switchTile('No similar characters (i, l, 1, O, 0)', _excludeSimilar,
            (v) {
          setState(() => _excludeSimilar = v);
          _generate();
        }),
        _switchTile('Easy to read', _easyToRead, (v) {
          setState(() => _easyToRead = v);
          _generate();
        }),
        _switchTile('Easy to speak (pronounceable)', _easyToSpeak, (v) {
          setState(() => _easyToSpeak = v);
          _generate();
        }),
      ],
    );
  }

  Widget _buildPassphraseOptions() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _sectionTitle('Number of words: ${_wordCount.round()}'),
        Slider(
          value: _wordCount,
          min: 3,
          max: 10,
          divisions: 7,
          label: _wordCount.round().toString(),
          onChanged: (v) {
            setState(() => _wordCount = v);
            _generate();
          },
        ),
        _sectionTitle('Separator'),
        Wrap(
          spacing: 10,
          children: ['-', '_', '.', ' '].map((sep) {
            final display = sep == ' ' ? 'space' : sep;
            return ChoiceChip(
              label: Text(display),
              selected: _separator == sep,
              onSelected: (_) {
                setState(() => _separator = sep);
                _generate();
              },
            );
          }).toList(),
        ),
        _switchTile('Capitalize words', _capitalizeWords, (v) {
          setState(() => _capitalizeWords = v);
          _generate();
        }),
        _switchTile('Include a number', _includeNumberInPassphrase, (v) {
          setState(() => _includeNumberInPassphrase = v);
          _generate();
        }),
      ],
    );
  }

  Widget _buildPinOptions() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _sectionTitle('PIN length: ${_pinLength.round()} digits'),
        Slider(
          value: _pinLength,
          min: 4,
          max: 12,
          divisions: 8,
          label: _pinLength.round().toString(),
          onChanged: (v) {
            setState(() => _pinLength = v);
            _generate();
          },
        ),
      ],
    );
  }

  Widget _sectionTitle(String text) => Padding(
        padding: const EdgeInsets.only(top: 12, bottom: 6),
        child: Text(
          text,
          style: Theme.of(context)
              .textTheme
              .titleSmall
              ?.copyWith(fontWeight: FontWeight.bold),
        ),
      );

  Widget _switchTile(String title, bool value, ValueChanged<bool> onChanged) {
    return SwitchListTile(
      contentPadding: EdgeInsets.zero,
      title: Text(title),
      value: value,
      onChanged: onChanged,
    );
  }
}
