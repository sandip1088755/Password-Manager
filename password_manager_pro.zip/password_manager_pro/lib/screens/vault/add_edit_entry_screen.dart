import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../models/entry_type.dart';
import '../../services/vault_repository.dart';
import '../generator/password_generator_screen.dart';
import '../sharing/qr_share_screen.dart';

class AddEditEntryScreen extends StatefulWidget {
  final PlainVaultEntry? existingEntry;
  final EntryTypeDef? entryType; // required when creating a new entry

  const AddEditEntryScreen({super.key, this.existingEntry, this.entryType});

  @override
  State<AddEditEntryScreen> createState() => _AddEditEntryScreenState();
}

class _AddEditEntryScreenState extends State<AddEditEntryScreen> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _titleController;
  late final TextEditingController _usernameController;
  late final TextEditingController _passwordController;
  late final TextEditingController _websiteController;
  late final TextEditingController _notesController;
  final Map<String, TextEditingController> _customControllers = {};
  final Map<String, bool> _customObscured = {};

  late EntryTypeDef _type;
  String _category = 'General';
  bool _favorite = false;
  bool _obscurePassword = true;
  bool _saving = false;

  static const _categories = [
    'General',
    'Social Media',
    'Banking',
    'Email',
    'Wi-Fi',
    'Work',
    'Shopping',
  ];

  bool get _isEditing => widget.existingEntry != null;

  @override
  void initState() {
    super.initState();
    final e = widget.existingEntry;
    _type = e != null
        ? EntryTypes.byId(e.entryType)
        : (widget.entryType ?? EntryTypes.login);

    _titleController = TextEditingController(text: e?.title ?? '');
    _usernameController = TextEditingController(text: e?.username ?? '');
    _passwordController = TextEditingController(text: e?.password ?? '');
    _websiteController = TextEditingController(text: e?.website ?? '');
    _notesController = TextEditingController(text: e?.notes ?? '');
    _category = e?.category ?? 'General';
    _favorite = e?.favorite ?? false;

    for (final field in _type.fields) {
      _customControllers[field.key] =
          TextEditingController(text: e?.customFields[field.key] ?? '');
      _customObscured[field.key] = field.kind == FieldKind.masked;
    }
  }

  @override
  void dispose() {
    for (final c in _customControllers.values) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _openGeneratorForPassword() async {
    final generated = await Navigator.of(context).push<String>(
      MaterialPageRoute(
        builder: (_) => const PasswordGeneratorScreen(returnsResult: true),
      ),
    );
    if (generated != null && generated.isNotEmpty) {
      setState(() => _passwordController.text = generated);
    }
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _saving = true);

    final customFields = <String, String>{
      for (final f in _type.fields) f.key: _customControllers[f.key]!.text.trim(),
    };

    final entry = PlainVaultEntry(
      id: widget.existingEntry?.id,
      title: _titleController.text.trim(),
      username: _usernameController.text.trim(),
      password: _passwordController.text,
      website: _websiteController.text.trim(),
      category: _category,
      notes: _notesController.text.trim(),
      favorite: _favorite,
      entryType: _type.id,
      customFields: customFields,
    );

    if (_isEditing) {
      await VaultRepository.instance.updateEntry(entry);
    } else {
      await VaultRepository.instance.addEntry(entry);
    }

    if (mounted) Navigator.of(context).pop(true);
  }

  Future<void> _delete() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete entry?'),
        content: const Text('This cannot be undone.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(context).pop(true),
            style: FilledButton.styleFrom(backgroundColor: Colors.red),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
    if (confirmed == true && widget.existingEntry?.id != null) {
      await VaultRepository.instance.deleteEntry(widget.existingEntry!.id!);
      if (mounted) Navigator.of(context).pop(true);
    }
  }

  void _copyToClipboard(String value, String label) {
    Clipboard.setData(ClipboardData(text: value));
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('$label copied')),
    );
  }

  @override
  Widget build(BuildContext context) {
    final showPasswordFields = _type.hasPassword;
    final showNotesOnly = _type.id == 'secure_note';

    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            Icon(_type.icon, size: 20),
            const SizedBox(width: 8),
            Text(_isEditing ? 'Edit ${_type.label}' : 'Add ${_type.label}'),
          ],
        ),
        actions: [
          if (_isEditing)
            IconButton(
              icon: const Icon(Icons.qr_code),
              tooltip: 'Share via QR',
              onPressed: () {
                final currentEntry = PlainVaultEntry(
                  id: widget.existingEntry?.id,
                  title: _titleController.text.trim(),
                  username: _usernameController.text.trim(),
                  password: _passwordController.text,
                  website: _websiteController.text.trim(),
                  category: _category,
                  notes: _notesController.text.trim(),
                  favorite: _favorite,
                  entryType: _type.id,
                  customFields: {
                    for (final f in _type.fields)
                      f.key: _customControllers[f.key]!.text.trim(),
                  },
                );
                Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (_) => QrShareScreen(entry: currentEntry),
                  ),
                );
              },
            ),
          IconButton(
            icon: Icon(_favorite ? Icons.star : Icons.star_border,
                color: _favorite ? Colors.amber : null),
            onPressed: () => setState(() => _favorite = !_favorite),
          ),
          if (_isEditing)
            IconButton(
              icon: const Icon(Icons.delete_outline),
              onPressed: _delete,
            ),
        ],
      ),
      body: SafeArea(
        child: Form(
          key: _formKey,
          child: ListView(
            padding: const EdgeInsets.all(20),
            children: [
              TextFormField(
                controller: _titleController,
                decoration: const InputDecoration(
                  labelText: 'Title *',
                  border: OutlineInputBorder(),
                ),
                validator: (v) =>
                    (v == null || v.trim().isEmpty) ? 'Required' : null,
              ),
              const SizedBox(height: 16),
              if (!showNotesOnly)
                DropdownButtonFormField<String>(
                  initialValue: _category,
                  decoration: const InputDecoration(
                    labelText: 'Category',
                    border: OutlineInputBorder(),
                  ),
                  items: _categories
                      .map((c) => DropdownMenuItem(value: c, child: Text(c)))
                      .toList(),
                  onChanged: (v) => setState(() => _category = v!),
                ),
              if (showPasswordFields) ...[
                const SizedBox(height: 16),
                TextFormField(
                  controller: _usernameController,
                  decoration: const InputDecoration(
                    labelText: 'Username / Email',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: _passwordController,
                  obscureText: _obscurePassword,
                  decoration: InputDecoration(
                    labelText: 'Password *',
                    border: const OutlineInputBorder(),
                    suffixIcon: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(
                          icon: const Icon(Icons.copy, size: 20),
                          onPressed: () => _copyToClipboard(
                              _passwordController.text, 'Password'),
                        ),
                        IconButton(
                          icon: Icon(
                            _obscurePassword
                                ? Icons.visibility
                                : Icons.visibility_off,
                            size: 20,
                          ),
                          onPressed: () => setState(
                              () => _obscurePassword = !_obscurePassword),
                        ),
                      ],
                    ),
                  ),
                  validator: (v) =>
                      (v == null || v.isEmpty) ? 'Required' : null,
                ),
                Align(
                  alignment: Alignment.centerRight,
                  child: TextButton.icon(
                    onPressed: _openGeneratorForPassword,
                    icon: const Icon(Icons.auto_fix_high, size: 18),
                    label: const Text('Generate strong password'),
                  ),
                ),
                const SizedBox(height: 8),
                TextFormField(
                  controller: _websiteController,
                  decoration: const InputDecoration(
                    labelText: 'Website',
                    border: OutlineInputBorder(),
                  ),
                ),
              ],

              // --- Dynamic fields for card/bank/identity types ---
              for (final field in _type.fields) ...[
                const SizedBox(height: 16),
                TextFormField(
                  controller: _customControllers[field.key],
                  obscureText: _customObscured[field.key] ?? false,
                  maxLines: field.kind == FieldKind.multiline ? 3 : 1,
                  keyboardType: field.kind == FieldKind.date
                      ? TextInputType.datetime
                      : TextInputType.text,
                  decoration: InputDecoration(
                    labelText: field.required ? '${field.label} *' : field.label,
                    hintText: field.kind == FieldKind.date ? 'DD/MM/YYYY' : null,
                    border: const OutlineInputBorder(),
                    suffixIcon: field.kind == FieldKind.masked
                        ? Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              IconButton(
                                icon: const Icon(Icons.copy, size: 20),
                                onPressed: () => _copyToClipboard(
                                  _customControllers[field.key]!.text,
                                  field.label,
                                ),
                              ),
                              IconButton(
                                icon: Icon(
                                  (_customObscured[field.key] ?? false)
                                      ? Icons.visibility
                                      : Icons.visibility_off,
                                  size: 20,
                                ),
                                onPressed: () => setState(() {
                                  _customObscured[field.key] =
                                      !(_customObscured[field.key] ?? false);
                                }),
                              ),
                            ],
                          )
                        : null,
                  ),
                  validator: (v) => (field.required && (v == null || v.trim().isEmpty))
                      ? 'Required'
                      : null,
                ),
              ],

              const SizedBox(height: 16),
              TextFormField(
                controller: _notesController,
                maxLines: showNotesOnly ? 10 : 4,
                decoration: InputDecoration(
                  labelText: showNotesOnly ? 'Note *' : 'Notes (encrypted)',
                  border: const OutlineInputBorder(),
                  alignLabelWithHint: true,
                ),
                validator: showNotesOnly
                    ? (v) => (v == null || v.trim().isEmpty) ? 'Required' : null
                    : null,
              ),
              const SizedBox(height: 24),
              FilledButton(
                onPressed: _saving ? null : _save,
                style: FilledButton.styleFrom(
                  minimumSize: const Size.fromHeight(52),
                ),
                child: _saving
                    ? const SizedBox(
                        height: 20,
                        width: 20,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : const Text('Save'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
