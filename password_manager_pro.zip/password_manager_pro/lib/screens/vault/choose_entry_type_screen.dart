import 'package:flutter/material.dart';

import '../../models/entry_type.dart';
import 'add_edit_entry_screen.dart';

class ChooseEntryTypeScreen extends StatelessWidget {
  const ChooseEntryTypeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Add New Item')),
      body: SafeArea(
        child: GridView.builder(
          padding: const EdgeInsets.all(16),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            mainAxisSpacing: 12,
            crossAxisSpacing: 12,
            childAspectRatio: 1.3,
          ),
          itemCount: EntryTypes.all.length,
          itemBuilder: (context, index) {
            final type = EntryTypes.all[index];
            return Card(
              clipBehavior: Clip.antiAlias,
              child: InkWell(
                onTap: () async {
                  final result = await Navigator.of(context).push<bool>(
                    MaterialPageRoute(
                      builder: (_) => AddEditEntryScreen(entryType: type),
                    ),
                  );
                  if (context.mounted) Navigator.of(context).pop(result);
                },
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(type.icon, size: 36),
                    const SizedBox(height: 8),
                    Text(
                      type.label,
                      textAlign: TextAlign.center,
                      style: const TextStyle(fontWeight: FontWeight.w600),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
