import 'package:flutter/material.dart';

import '../../models/entry_type.dart';
import '../../services/auth_service.dart';
import '../../services/vault_repository.dart';
import '../generator/password_generator_screen.dart';
import '../settings/settings_screen.dart';
import '../files/secure_files_screen.dart';
import '../sharing/qr_scan_screen.dart';
import 'add_edit_entry_screen.dart';
import 'choose_entry_type_screen.dart';
import 'login_screen.dart';

class VaultHomeScreen extends StatefulWidget {
  const VaultHomeScreen({super.key});

  @override
  State<VaultHomeScreen> createState() => _VaultHomeScreenState();
}

class _VaultHomeScreenState extends State<VaultHomeScreen> {
  final _repo = VaultRepository.instance;
  final _searchController = TextEditingController();

  List<PlainVaultEntry> _entries = [];
  String _selectedCategory = 'All';
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadEntries();
  }

  Future<void> _loadEntries() async {
    setState(() => _loading = true);
    final query = _searchController.text.trim();
    final entries =
        query.isEmpty ? await _repo.getAllEntries() : await _repo.search(query);
    if (!mounted) return;
    setState(() {
      _entries = entries;
      _loading = false;
    });
  }

  List<PlainVaultEntry> get _filteredEntries {
    if (_selectedCategory == 'All') return _entries;
    if (_selectedCategory == 'Favorites') {
      return _entries.where((e) => e.favorite).toList();
    }
    return _entries.where((e) => e.category == _selectedCategory).toList();
  }

  List<String> get _categories {
    final set = <String>{'All', 'Favorites'};
    for (final e in _entries) {
      set.add(e.category);
    }
    return set.toList();
  }

  void _lockVault() {
    AuthService.instance.lock();
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => const LoginScreen()),
      (route) => false,
    );
  }

  Future<void> _openAddEntry() async {
    final result = await Navigator.of(context).push<bool>(
      MaterialPageRoute(builder: (_) => const ChooseEntryTypeScreen()),
    );
    if (result == true) _loadEntries();
  }

  Future<void> _openEditEntry(PlainVaultEntry entry) async {
    final result = await Navigator.of(context).push<bool>(
      MaterialPageRoute(
        builder: (_) => AddEditEntryScreen(existingEntry: entry),
      ),
    );
    if (result == true) _loadEntries();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('My Vault'),
        actions: [
          IconButton(
            icon: const Icon(Icons.folder_special_outlined),
            tooltip: 'Secure Files',
            onPressed: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const SecureFilesScreen()),
            ),
          ),
          IconButton(
            icon: const Icon(Icons.settings_outlined),
            tooltip: 'Settings',
            onPressed: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const SettingsScreen()),
            ),
          ),
          IconButton(
            icon: const Icon(Icons.lock_outline),
            tooltip: 'Lock vault',
            onPressed: _lockVault,
          ),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
              child: TextField(
                controller: _searchController,
                onChanged: (_) => _loadEntries(),
                decoration: InputDecoration(
                  hintText: 'Search vault...',
                  prefixIcon: const Icon(Icons.search),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(14),
                  ),
                ),
              ),
            ),
            SizedBox(
              height: 40,
              child: ListView(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 12),
                children: _categories.map((c) {
                  final selected = c == _selectedCategory;
                  return Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 4),
                    child: ChoiceChip(
                      label: Text(c),
                      selected: selected,
                      onSelected: (_) =>
                          setState(() => _selectedCategory = c),
                    ),
                  );
                }).toList(),
              ),
            ),
            const SizedBox(height: 8),
            Expanded(
              child: _loading
                  ? const Center(child: CircularProgressIndicator())
                  : _filteredEntries.isEmpty
                      ? _buildEmptyState()
                      : ListView.builder(
                          itemCount: _filteredEntries.length,
                          itemBuilder: (context, index) {
                            final entry = _filteredEntries[index];
                            final type = EntryTypes.byId(entry.entryType);
                            final subtitle = entry.entryType == 'login'
                                ? entry.username
                                : (entry.entryType == 'secure_note'
                                    ? 'Secure Note'
                                    : type.label);
                            return ListTile(
                              leading: CircleAvatar(
                                child: Icon(type.icon, size: 20),
                              ),
                              title: Text(entry.title),
                              subtitle: Text(subtitle),
                              trailing: entry.favorite
                                  ? const Icon(Icons.star,
                                      color: Colors.amber)
                                  : null,
                              onTap: () => _openEditEntry(entry),
                            );
                          },
                        ),
            ),
          ],
        ),
      ),
      floatingActionButton: Column(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          FloatingActionButton.small(
            heroTag: 'qrscan',
            onPressed: () async {
              final imported = await Navigator.of(context).push<bool>(
                MaterialPageRoute(builder: (_) => const QrScanScreen()),
              );
              if (imported == true) _loadEntries();
            },
            child: const Icon(Icons.qr_code_scanner),
          ),
          const SizedBox(height: 12),
          FloatingActionButton.small(
            heroTag: 'generator',
            onPressed: () => Navigator.of(context).push(
              MaterialPageRoute(
                builder: (_) => const PasswordGeneratorScreen(),
              ),
            ),
            child: const Icon(Icons.vpn_key),
          ),
          const SizedBox(height: 12),
          FloatingActionButton.extended(
            heroTag: 'add',
            onPressed: _openAddEntry,
            icon: const Icon(Icons.add),
            label: const Text('Add'),
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.inbox_outlined, size: 56, color: Colors.grey.shade400),
          const SizedBox(height: 12),
          Text(
            _searchController.text.isEmpty
                ? 'Your vault is empty.\nTap + to add your first entry.'
                : 'No matching entries.',
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.grey.shade600),
          ),
        ],
      ),
    );
  }
}
