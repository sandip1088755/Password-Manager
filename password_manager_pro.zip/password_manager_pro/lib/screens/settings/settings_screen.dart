import 'package:flutter/material.dart';

import '../../services/auth_service.dart';
import '../../services/autofill_bridge.dart';
import '../../services/settings_service.dart';
import '../../services/theme_service.dart';
import '../../main.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  int _autoLockMinutes = 1;
  bool _biometricAvailable = false;
  bool _biometricEnabled = false;
  bool _autofillEnabled = false;
  String _selectedThemeId = ThemeService.presets.first.id;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final minutes = await SettingsService.instance.getAutoLockMinutes();
    final available = await AuthService.instance.isBiometricAvailable();
    final enabled = await AuthService.instance.isBiometricEnabled();
    final autofillOn =
        await AutofillBridge.instance.isAutofillServiceEnabled();
    final themeId = await ThemeService.instance.getSelectedPresetId();
    if (!mounted) return;
    setState(() {
      _autoLockMinutes = minutes;
      _biometricAvailable = available;
      _biometricEnabled = enabled;
      _autofillEnabled = autofillOn;
      _selectedThemeId = themeId;
    });
  }

  Future<void> _selectTheme(String id) async {
    await ThemeService.instance.setSelectedPresetId(id);
    setState(() => _selectedThemeId = id);
    await PasswordManagerProApp.of(context)?.refreshTheme();
  }

  Future<void> _openAutofillSettings() async {
    await AutofillBridge.instance.openAutofillSettings();
    // Re-check status once the user returns from system settings.
    await Future.delayed(const Duration(milliseconds: 500));
    _load();
  }

  Future<void> _toggleBiometric(bool value) async {
    if (value) {
      await AuthService.instance.enableBiometricUnlock();
    } else {
      await AuthService.instance.disableBiometricUnlock();
    }
    setState(() => _biometricEnabled = value);
  }

  Future<void> _showChangePasswordDialog() async {
    final currentController = TextEditingController();
    final newController = TextEditingController();
    final confirmController = TextEditingController();
    String? error;

    await showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: const Text('Change Master Password'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: currentController,
                obscureText: true,
                decoration:
                    const InputDecoration(labelText: 'Current password'),
              ),
              TextField(
                controller: newController,
                obscureText: true,
                decoration: const InputDecoration(labelText: 'New password'),
              ),
              TextField(
                controller: confirmController,
                obscureText: true,
                decoration:
                    const InputDecoration(labelText: 'Confirm new password'),
              ),
              if (error != null) ...[
                const SizedBox(height: 8),
                Text(error!, style: const TextStyle(color: Colors.red)),
              ],
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('Cancel'),
            ),
            FilledButton(
              onPressed: () async {
                if (newController.text.length < 8) {
                  setDialogState(() => error = 'Minimum 8 characters');
                  return;
                }
                if (newController.text != confirmController.text) {
                  setDialogState(() => error = 'Passwords do not match');
                  return;
                }
                final ok = await AuthService.instance.changeMasterPassword(
                  currentController.text,
                  newController.text,
                );
                if (!ok) {
                  setDialogState(() => error = 'Current password incorrect');
                  return;
                }
                if (context.mounted) Navigator.of(context).pop();
                if (mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Master password updated')),
                  );
                }
              },
              child: const Text('Update'),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: ListView(
        children: [
          ListTile(
            title: const Text('Auto-lock after'),
            subtitle: Text(_autoLockMinutes == 0
                ? 'Immediately'
                : '$_autoLockMinutes minute(s) in background'),
            trailing: DropdownButton<int>(
              value: _autoLockMinutes,
              items: const [0, 1, 2, 5, 10]
                  .map((m) => DropdownMenuItem(
                        value: m,
                        child: Text(m == 0 ? 'Immediate' : '$m min'),
                      ))
                  .toList(),
              onChanged: (v) async {
                if (v == null) return;
                await SettingsService.instance.setAutoLockMinutes(v);
                setState(() => _autoLockMinutes = v);
              },
            ),
          ),
          if (_biometricAvailable)
            SwitchListTile(
              title: const Text('Biometric unlock'),
              subtitle: const Text('Use fingerprint/face instead of typing '
                  'your master password'),
              value: _biometricEnabled,
              onChanged: _toggleBiometric,
            ),
          ListTile(
            title: const Text('Change master password'),
            leading: const Icon(Icons.password),
            onTap: _showChangePasswordDialog,
          ),
          const Divider(),
          ListTile(
            title: const Text('Autofill (fill FB/Insta/bank logins)'),
            subtitle: Text(_autofillEnabled
                ? 'Enabled — this app is your autofill provider'
                : 'Not enabled — tap to turn on in system settings'),
            leading: Icon(
              Icons.auto_awesome,
              color: _autofillEnabled ? Colors.green : null,
            ),
            trailing: _autofillEnabled
                ? const Icon(Icons.check_circle, color: Colors.green)
                : const Icon(Icons.chevron_right),
            onTap: _autofillEnabled ? null : _openAutofillSettings,
          ),
          const Divider(),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
            child: Text('Premium Themes',
                style: Theme.of(context).textTheme.titleSmall),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Wrap(
              spacing: 12,
              runSpacing: 12,
              children: ThemeService.presets.map((preset) {
                final selected = preset.id == _selectedThemeId;
                return GestureDetector(
                  onTap: () => _selectTheme(preset.id),
                  child: Column(
                    children: [
                      Container(
                        width: 48,
                        height: 48,
                        decoration: BoxDecoration(
                          color: preset.seedColor,
                          shape: BoxShape.circle,
                          border: selected
                              ? Border.all(color: Colors.black, width: 3)
                              : null,
                        ),
                        child: selected
                            ? const Icon(Icons.check, color: Colors.white)
                            : null,
                      ),
                      const SizedBox(height: 4),
                      Text(preset.label, style: const TextStyle(fontSize: 11)),
                    ],
                  ),
                );
              }).toList(),
            ),
          ),
          const SizedBox(height: 12),
          const Divider(),
          const Padding(
            padding: EdgeInsets.all(16),
            child: Text(
              'Cloud sync and import from other password managers are not '
              'part of this MVP build — they need Firebase / per-format '
              'parsers that have to be set up in your own project.',
              style: TextStyle(color: Colors.grey, fontSize: 12),
            ),
          ),
        ],
      ),
    );
  }
}
