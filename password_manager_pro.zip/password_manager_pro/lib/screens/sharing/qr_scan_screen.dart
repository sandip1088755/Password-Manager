import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:mobile_scanner/mobile_scanner.dart';

import '../../services/vault_repository.dart';

class QrScanScreen extends StatefulWidget {
  const QrScanScreen({super.key});

  @override
  State<QrScanScreen> createState() => _QrScanScreenState();
}

class _QrScanScreenState extends State<QrScanScreen> {
  bool _handled = false;

  Future<void> _onDetect(BarcodeCapture capture) async {
    if (_handled) return;
    if (capture.barcodes.isEmpty) return;
    final raw = capture.barcodes.first.rawValue;
    if (raw == null) return;

    Map<String, dynamic> data;
    try {
      data = jsonDecode(raw) as Map<String, dynamic>;
    } catch (_) {
      return; // not our QR format — ignore and keep scanning
    }

    final ts = data['ts'] as int?;
    if (ts == null ||
        DateTime.now().millisecondsSinceEpoch - ts > 5 * 60 * 1000) {
      _handled = true;
      _showExpiredDialog();
      return;
    }

    _handled = true;
    _showConfirmDialog(data);
  }

  void _showExpiredDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('QR code expired'),
        content: const Text(
          'This share code is older than 5 minutes and can no longer be '
          'imported. Ask for a fresh QR code.',
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
              setState(() => _handled = false);
            },
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  Future<void> _showConfirmDialog(Map<String, dynamic> data) async {
    final title = data['title'] as String? ?? 'Untitled';
    final username = data['username'] as String? ?? '';

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Import shared item?'),
        content: Text('"$title"${username.isNotEmpty ? ' ($username)' : ''} '
            'will be added to your vault, encrypted with your master password.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(context).pop(true),
            child: const Text('Import'),
          ),
        ],
      ),
    );

    if (confirmed == true) {
      final entry = PlainVaultEntry(
        title: title,
        username: username,
        password: data['password'] as String? ?? '',
        website: data['website'] as String? ?? '',
        notes: data['notes'] as String? ?? '',
        entryType: data['entryType'] as String? ?? 'login',
        customFields: (data['customFields'] as Map?)
                ?.map((k, v) => MapEntry(k.toString(), v.toString())) ??
            {},
      );
      await VaultRepository.instance.addEntry(entry);
      if (mounted) Navigator.of(context).pop(true);
    } else {
      setState(() => _handled = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Scan Shared QR Code')),
      body: MobileScanner(onDetect: _onDetect),
    );
  }
}
