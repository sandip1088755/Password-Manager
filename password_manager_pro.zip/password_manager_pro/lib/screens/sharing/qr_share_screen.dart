import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:qr_flutter/qr_flutter.dart';

import '../../services/vault_repository.dart';

class QrShareScreen extends StatelessWidget {
  final PlainVaultEntry entry;

  const QrShareScreen({super.key, required this.entry});

  String _buildPayload() {
    final map = {
      'v': 1,
      'ts': DateTime.now().millisecondsSinceEpoch,
      'title': entry.title,
      'username': entry.username,
      'password': entry.password,
      'website': entry.website,
      'notes': entry.notes,
      'entryType': entry.entryType,
      'customFields': entry.customFields,
    };
    return jsonEncode(map);
  }

  @override
  Widget build(BuildContext context) {
    final payload = _buildPayload();

    return Scaffold(
      appBar: AppBar(title: const Text('Share via QR Code')),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.08),
                      blurRadius: 12,
                    ),
                  ],
                ),
                child: QrImageView(
                  data: payload,
                  version: QrVersions.auto,
                  size: 260,
                  errorCorrectionLevel: QrErrorCorrectLevel.M,
                ),
              ),
              const SizedBox(height: 20),
              Text(
                'Sharing "${entry.title}"',
                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
              ),
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.orange.shade50,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: Colors.orange.shade200),
                ),
                child: const Row(
                  children: [
                    Icon(Icons.info_outline, color: Colors.orange, size: 20),
                    SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        'This QR code contains the password in plain form. '
                        'Only show it to someone you trust, in person. It '
                        'expires 5 minutes after generation for safety.',
                        style: TextStyle(fontSize: 12.5),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
