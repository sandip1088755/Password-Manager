// encryption_service.dart
//
// All real cryptography lives here:
//   • PBKDF2-HMAC-SHA256 key derivation (100,000 iterations) from the
//     user's master password + a random per-install salt.
//   • AES-256-GCM authenticated encryption for every sensitive field
//     stored in the vault (passwords, notes, card numbers, etc).
//
// This is a genuine implementation (via `encrypt` + `pointycastle`), not a
// stub — but please still get it reviewed by a security professional
// before shipping anything that stores real user credentials.

import 'dart:convert';
import 'dart:math';
import 'dart:typed_data';

import 'package:encrypt/encrypt.dart' as enc;
import 'package:pointycastle/export.dart' as pc;

class EncryptionService {
  static const int _saltLengthBytes = 16;
  static const int _keyLengthBytes = 32; // AES-256
  static const int _pbkdf2Iterations = 100000;
  static const int _gcmIvLengthBytes = 12;

  final Random _secureRandom = Random.secure();

  /// Generates a new random salt. Store this — you need it to re-derive
  /// the same key from the master password next time the app opens.
  Uint8List generateSalt() => _randomBytes(_saltLengthBytes);

  Uint8List _randomBytes(int length) {
    final bytes = Uint8List(length);
    for (var i = 0; i < length; i++) {
      bytes[i] = _secureRandom.nextInt(256);
    }
    return bytes;
  }

  /// Derives a 256-bit key from the master password using PBKDF2-HMAC-SHA256.
  Uint8List deriveKey(String masterPassword, Uint8List salt) {
    final derivator = pc.PBKDF2KeyDerivator(pc.HMac(pc.SHA256Digest(), 64))
      ..init(pc.Pbkdf2Parameters(salt, _pbkdf2Iterations, _keyLengthBytes));
    return derivator.process(Uint8List.fromList(utf8.encode(masterPassword)));
  }

  /// Produces a verifier for the master password without ever storing the
  /// password (or the raw key) itself. We store this + the salt; on login
  /// we re-derive and compare verifiers.
  String computeVerifier(Uint8List key) {
    final hmac = pc.HMac(pc.SHA256Digest(), 64)
      ..init(pc.KeyParameter(key));
    final out = hmac.process(Uint8List.fromList(utf8.encode('vault-verify')));
    return base64Encode(out);
  }

  /// Encrypts [plainText] with AES-256-GCM under [key].
  /// Output format: base64(iv + ciphertext + authTag), all concatenated,
  /// so a single string can be stored per field.
  String encryptText(String plainText, Uint8List key) {
    final iv = enc.IV(_randomBytes(_gcmIvLengthBytes));
    final encrypter = enc.Encrypter(
      enc.AES(enc.Key(key), mode: enc.AESMode.gcm),
    );
    final encrypted = encrypter.encrypt(plainText, iv: iv);
    final combined = Uint8List.fromList([...iv.bytes, ...encrypted.bytes]);
    return base64Encode(combined);
  }

  /// Decrypts a string produced by [encryptText].
  String decryptText(String cipherTextBase64, Uint8List key) {
    final combined = base64Decode(cipherTextBase64);
    final iv = enc.IV(Uint8List.fromList(combined.sublist(0, _gcmIvLengthBytes)));
    final cipherBytes = combined.sublist(_gcmIvLengthBytes);
    final encrypter = enc.Encrypter(
      enc.AES(enc.Key(key), mode: enc.AESMode.gcm),
    );
    return encrypter.decrypt(enc.Encrypted(cipherBytes), iv: iv);
  }
}
