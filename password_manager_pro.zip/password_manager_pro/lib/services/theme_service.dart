// theme_service.dart — a handful of curated Material 3 color presets
// ("Premium Themes"). Since this app has no payment/subscription backend
// wired up, all presets are unlocked for now — gating them behind a
// purchase flow would need a billing integration (Google Play Billing),
// which is a separate piece of infra to add when you're ready to monetize.

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ThemePreset {
  final String id;
  final String label;
  final Color seedColor;

  const ThemePreset(this.id, this.label, this.seedColor);
}

class ThemeService {
  static final ThemeService instance = ThemeService._internal();
  ThemeService._internal();

  static const _kThemeKey = 'selected_theme_preset';

  static const List<ThemePreset> presets = [
    ThemePreset('deep_purple', 'Royal Purple', Colors.deepPurple),
    ThemePreset('midnight_blue', 'Midnight Blue', Colors.indigo),
    ThemePreset('emerald', 'Emerald Vault', Colors.teal),
    ThemePreset('crimson', 'Crimson Guard', Colors.red),
    ThemePreset('sunset', 'Sunset Gold', Colors.deepOrange),
    ThemePreset('graphite', 'Graphite Pro', Colors.blueGrey),
  ];

  Future<String> getSelectedPresetId() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_kThemeKey) ?? presets.first.id;
  }

  Future<void> setSelectedPresetId(String id) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_kThemeKey, id);
  }

  ThemePreset presetById(String id) =>
      presets.firstWhere((p) => p.id == id, orElse: () => presets.first);
}
