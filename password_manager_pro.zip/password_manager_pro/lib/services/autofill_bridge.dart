// autofill_bridge.dart — talks to the native Android AutofillService.
//
// The Autofill framework runs as a separate OS-managed service
// (VaultAutofillService.kt) that Android calls into directly — it does
// NOT go through your running Flutter app/Dart isolate. So the native
// service needs its own copy of the session key to decrypt entries, and
// it reads the same SQLite vault.db file directly.
//
// This bridge's job is simple: whenever the Flutter side unlocks/locks
// the vault, mirror that session key (or its absence) into Android's
// EncryptedSharedPreferences (Keystore-backed) so the native service can
// use it — and clear it immediately on lock so autofill stops working
// the moment the vault locks, matching the rest of the app's security
// model.

import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter/services.dart';

class AutofillBridge {
  static final AutofillBridge instance = AutofillBridge._internal();
  AutofillBridge._internal();

  static const _channel =
      MethodChannel('com.example.password_manager_pro/autofill');

  /// Called right after a successful master-password login, biometric
  /// unlock, or fresh setup — mirrors the session key to native storage.
  Future<void> pushSessionKey(Uint8List key) async {
    try {
      await _channel.invokeMethod('setSessionKey', {
        'key': base64Encode(key),
      });
    } catch (_) {
      // Autofill mirroring is a nice-to-have; never let it break login.
    }
  }

  /// Called on lock() / app backgrounded past auto-lock timeout — wipes
  /// the native copy of the key so autofill can't decrypt anything until
  /// the next unlock.
  Future<void> clearSessionKey() async {
    try {
      await _channel.invokeMethod('clearSessionKey');
    } catch (_) {}
  }

  /// Whether this app is currently set as the system's autofill provider.
  Future<bool> isAutofillServiceEnabled() async {
    try {
      final result = await _channel.invokeMethod<bool>('isAutofillEnabled');
      return result ?? false;
    } catch (_) {
      return false;
    }
  }

  /// Opens Android's system settings screen where the user picks this
  /// app as their autofill provider (Settings > Passwords > Autofill
  /// service). There is no API to enable it silently — the user must
  /// confirm this themselves, by design, on every Android version.
  Future<void> openAutofillSettings() async {
    try {
      await _channel.invokeMethod('openAutofillSettings');
    } catch (_) {}
  }
}
