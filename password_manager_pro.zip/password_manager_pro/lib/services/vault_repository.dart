// vault_repository.dart — the only place screens should talk to for
// reading/writing vault entries. Screens never touch encryption directly;
// they pass and receive plaintext, and this class handles encrypt/decrypt
// using the current session key from AuthService.

import 'dart:convert';

import '../core/encryption_service.dart';
import '../models/vault_entry.dart';
import 'auth_service.dart';
import 'database_service.dart';

class PlainVaultEntry {
  final int? id;
  final String title;
  final String username;
  final String password; // plaintext, only ever held in memory
  final String website;
  final String category;
  final String notes; // plaintext
  final bool favorite;
  final String entryType; // 'login', 'card', 'bank_account', ...
  final Map<String, String> customFields; // type-specific fields, plaintext

  PlainVaultEntry({
    this.id,
    required this.title,
    this.username = '',
    this.password = '',
    this.website = '',
    this.category = 'General',
    this.notes = '',
    this.favorite = false,
    this.entryType = 'login',
    this.customFields = const {},
  });
}

class VaultRepository {
  static final VaultRepository instance = VaultRepository._internal();
  VaultRepository._internal();

  final _db = DatabaseService.instance;
  final _auth = AuthService.instance;
  final _crypto = EncryptionService();

  Future<int> addEntry(PlainVaultEntry entry) async {
    final key = _auth.requireSessionKey;
    final record = VaultEntry(
      title: entry.title,
      username: entry.username,
      encryptedPassword:
          entry.password.isEmpty ? '' : _crypto.encryptText(entry.password, key),
      website: entry.website,
      category: entry.category,
      encryptedNotes:
          entry.notes.isEmpty ? '' : _crypto.encryptText(entry.notes, key),
      favorite: entry.favorite,
      entryType: entry.entryType,
      encryptedCustomFields: entry.customFields.isEmpty
          ? ''
          : _crypto.encryptText(jsonEncode(entry.customFields), key),
    );
    return _db.insertEntry(record);
  }

  Future<int> updateEntry(PlainVaultEntry entry) async {
    if (entry.id == null) {
      throw ArgumentError('Cannot update an entry without an id');
    }
    final key = _auth.requireSessionKey;
    final record = VaultEntry(
      id: entry.id,
      title: entry.title,
      username: entry.username,
      encryptedPassword:
          entry.password.isEmpty ? '' : _crypto.encryptText(entry.password, key),
      website: entry.website,
      category: entry.category,
      encryptedNotes:
          entry.notes.isEmpty ? '' : _crypto.encryptText(entry.notes, key),
      favorite: entry.favorite,
      entryType: entry.entryType,
      encryptedCustomFields: entry.customFields.isEmpty
          ? ''
          : _crypto.encryptText(jsonEncode(entry.customFields), key),
      updatedAt: DateTime.now(),
    );
    return _db.updateEntry(record);
  }

  Future<int> deleteEntry(int id) => _db.deleteEntry(id);

  PlainVaultEntry _decrypt(VaultEntry r, dynamic key) {
    Map<String, String> customFields = {};
    if (r.encryptedCustomFields.isNotEmpty) {
      try {
        final decoded =
            jsonDecode(_crypto.decryptText(r.encryptedCustomFields, key));
        customFields = Map<String, String>.from(decoded as Map);
      } catch (_) {
        customFields = {};
      }
    }
    return PlainVaultEntry(
      id: r.id,
      title: r.title,
      username: r.username,
      password: r.encryptedPassword.isEmpty
          ? ''
          : _crypto.decryptText(r.encryptedPassword, key),
      website: r.website,
      category: r.category,
      notes: r.encryptedNotes.isEmpty
          ? ''
          : _crypto.decryptText(r.encryptedNotes, key),
      favorite: r.favorite,
      entryType: r.entryType,
      customFields: customFields,
    );
  }

  Future<List<PlainVaultEntry>> getAllEntries() async {
    final key = _auth.requireSessionKey;
    final rows = await _db.getAllEntries();
    return rows.map((r) => _decrypt(r, key)).toList();
  }

  Future<List<PlainVaultEntry>> search(String query) async {
    final key = _auth.requireSessionKey;
    final rows = await _db.searchEntries(query);
    return rows.map((r) => _decrypt(r, key)).toList();
  }
}
