// secure_file_service.dart — encrypts arbitrary files (photos, PDFs,
// documents) with the same AES-256-GCM used for vault text fields, and
// stores the ciphertext bytes in the app's private storage directory
// (not accessible to other apps or the user without root).
//
// Large files are encrypted as a byte stream in a single AES-GCM call —
// fine up to tens of MB (typical ID scans / photos). For very large
// files you'd want chunked/streaming encryption instead; note that as a
// known limitation rather than silently degrading.

import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:path_provider/path_provider.dart';

import '../core/encryption_service.dart';
import 'auth_service.dart';
import 'database_service.dart';

class SecureFileRecord {
  final int id;
  final String displayName;
  final String fileType; // 'image', 'pdf', 'document', 'other'
  final String encryptedFilePath;
  final int sizeBytes;
  final DateTime createdAt;

  SecureFileRecord({
    required this.id,
    required this.displayName,
    required this.fileType,
    required this.encryptedFilePath,
    required this.sizeBytes,
    required this.createdAt,
  });

  factory SecureFileRecord.fromMap(Map<String, Object?> map) => SecureFileRecord(
        id: map['id'] as int,
        displayName: map['display_name'] as String,
        fileType: map['file_type'] as String,
        encryptedFilePath: map['encrypted_file_path'] as String,
        sizeBytes: map['size_bytes'] as int,
        createdAt: DateTime.parse(map['created_at'] as String),
      );
}

class SecureFileService {
  static final SecureFileService instance = SecureFileService._internal();
  SecureFileService._internal();

  final _crypto = EncryptionService();
  final _auth = AuthService.instance;
  final _db = DatabaseService.instance;

  Future<Directory> _vaultFilesDir() async {
    final docsDir = await getApplicationDocumentsDirectory();
    final dir = Directory('${docsDir.path}/secure_files');
    if (!await dir.exists()) {
      await dir.create(recursive: true);
    }
    return dir;
  }

  String classifyFileType(String fileName) {
    final ext = fileName.split('.').last.toLowerCase();
    if (['jpg', 'jpeg', 'png', 'webp', 'heic'].contains(ext)) return 'image';
    if (ext == 'pdf') return 'pdf';
    if (['doc', 'docx', 'txt', 'xlsx', 'ppt', 'pptx'].contains(ext)) {
      return 'document';
    }
    return 'other';
  }

  /// Encrypts [sourceFile] and stores it under the app's private
  /// documents directory. Returns the created DB record id.
  Future<int> encryptAndStore(File sourceFile, String displayName) async {
    final key = _auth.requireSessionKey;
    final bytes = await sourceFile.readAsBytes();

    // Reuse EncryptionService's text path by base64-encoding the raw
    // bytes, then encrypting that string — simplest way to reuse the
    // exact same AES-GCM implementation without duplicating crypto code.
    final base64Payload = base64Encode(bytes);
    final encryptedPayload = _crypto.encryptText(base64Payload, key);

    final dir = await _vaultFilesDir();
    final destFileName =
        '${DateTime.now().millisecondsSinceEpoch}_${displayName.hashCode}.enc';
    final destFile = File('${dir.path}/$destFileName');
    await destFile.writeAsString(encryptedPayload);

    return _db.insertFileRecord(
      displayName: displayName,
      fileType: classifyFileType(displayName),
      encryptedFilePath: destFile.path,
      sizeBytes: bytes.length,
    );
  }

  /// Decrypts a stored file back to plain bytes (kept only in memory —
  /// caller decides whether to write a temp file for viewing/sharing).
  Future<Uint8List> decryptFile(String encryptedFilePath) async {
    final key = _auth.requireSessionKey;
    final file = File(encryptedFilePath);
    final encryptedPayload = await file.readAsString();
    final base64Payload = _crypto.decryptText(encryptedPayload, key);
    return base64Decode(base64Payload);
  }

  Future<List<SecureFileRecord>> getAllFiles() async {
    final rows = await _db.getAllFileRecords();
    return rows.map(SecureFileRecord.fromMap).toList();
  }

  Future<void> deleteFile(SecureFileRecord record) async {
    await _db.deleteFileRecord(record.id);
    final file = File(record.encryptedFilePath);
    if (await file.exists()) {
      await file.delete();
    }
  }
}
