// auth_service.dart — master password + biometric unlock + session key.
//
// Zero-knowledge design: the master password itself is never stored.
// Only a random salt and a keyed-hash "verifier" live on disk (inside
// flutter_secure_storage, which is backed by Android Keystore / iOS
// Keychain). The AES key used to encrypt/decrypt vault data is derived
// fresh from the password every time and kept ONLY in memory for the
// current session — it disappears on lock/auto-lock/app kill.

import 'dart:convert';
import 'dart:typed_data';

import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:local_auth/local_auth.dart';

import '../core/encryption_service.dart';
import 'autofill_bridge.dart';

class AuthService {
  static final AuthService instance = AuthService._internal();
  AuthService._internal();

  final _secureStorage = const FlutterSecureStorage();
  final _encryptionService = EncryptionService();
  final _localAuth = LocalAuthentication();

  static const _kSaltKey = 'master_salt';
  static const _kVerifierKey = 'master_verifier';
  static const _kBiometricWrappedKey = 'biometric_wrapped_key';
  static const _kBiometricEnabledKey = 'biometric_enabled';

  /// Session-only AES key, held in memory while the vault is unlocked.
  Uint8List? _sessionKey;

  bool get isUnlocked => _sessionKey != null;

  Uint8List get requireSessionKey {
    if (_sessionKey == null) {
      throw StateError('Vault is locked — no session key available.');
    }
    return _sessionKey!;
  }

  Future<bool> hasMasterPassword() async {
    final salt = await _secureStorage.read(key: _kSaltKey);
    return salt != null;
  }

  /// First-run setup: derive a key from [password], store only the salt
  /// and a verifier (never the password or the key).
  Future<void> setupMasterPassword(String password) async {
    final salt = _encryptionService.generateSalt();
    final key = _encryptionService.deriveKey(password, salt);
    final verifier = _encryptionService.computeVerifier(key);

    await _secureStorage.write(key: _kSaltKey, value: base64Encode(salt));
    await _secureStorage.write(key: _kVerifierKey, value: verifier);

    _sessionKey = key; // start unlocked right after setup
    await AutofillBridge.instance.pushSessionKey(key);
  }

  /// Verifies [password] against the stored salt+verifier. On success,
  /// loads the derived key into the in-memory session.
  Future<bool> login(String password) async {
    final saltB64 = await _secureStorage.read(key: _kSaltKey);
    final storedVerifier = await _secureStorage.read(key: _kVerifierKey);
    if (saltB64 == null || storedVerifier == null) return false;

    final salt = base64Decode(saltB64);
    final key = _encryptionService.deriveKey(password, salt);
    final verifier = _encryptionService.computeVerifier(key);

    if (verifier == storedVerifier) {
      _sessionKey = key;
      await AutofillBridge.instance.pushSessionKey(key);
      return true;
    }
    return false;
  }

  /// Locks the vault: wipes the in-memory key. Nothing can be decrypted
  /// again until login() or unlockWithBiometrics() succeeds.
  void lock() {
    _sessionKey = null;
    AutofillBridge.instance.clearSessionKey();
  }

  Future<bool> isBiometricAvailable() async {
    try {
      final canCheck = await _localAuth.canCheckBiometrics;
      final isSupported = await _localAuth.isDeviceSupported();
      return canCheck && isSupported;
    } catch (_) {
      return false;
    }
  }

  Future<bool> isBiometricEnabled() async {
    final v = await _secureStorage.read(key: _kBiometricEnabledKey);
    return v == 'true';
  }

  /// Enables biometric unlock: must be called while already unlocked
  /// (i.e. right after a successful password login), because we need the
  /// current session key to wrap and store it for next time. The key
  /// itself is protected by the OS keystore via flutter_secure_storage,
  /// not by biometrics directly — the biometric prompt just gates read
  /// access to that secure-storage entry at the OS level.
  Future<void> enableBiometricUnlock() async {
    if (_sessionKey == null) {
      throw StateError('Unlock with master password before enabling '
          'biometrics.');
    }
    await _secureStorage.write(
      key: _kBiometricWrappedKey,
      value: base64Encode(_sessionKey!),
    );
    await _secureStorage.write(key: _kBiometricEnabledKey, value: 'true');
  }

  Future<void> disableBiometricUnlock() async {
    await _secureStorage.delete(key: _kBiometricWrappedKey);
    await _secureStorage.write(key: _kBiometricEnabledKey, value: 'false');
  }

  /// Prompts Face/Fingerprint unlock, then restores the session key from
  /// secure storage on success.
  Future<bool> unlockWithBiometrics() async {
    final enabled = await isBiometricEnabled();
    if (!enabled) return false;

    try {
      final authenticated = await _localAuth.authenticate(
        localizedReason: 'Unlock your password vault',
        options: const AuthenticationOptions(
          biometricOnly: true,
          stickyAuth: true,
        ),
      );
      if (!authenticated) return false;

      final wrappedKeyB64 =
          await _secureStorage.read(key: _kBiometricWrappedKey);
      if (wrappedKeyB64 == null) return false;

      _sessionKey = base64Decode(wrappedKeyB64);
      await AutofillBridge.instance.pushSessionKey(_sessionKey!);
      return true;
    } catch (_) {
      return false;
    }
  }

  /// Changes the master password: requires the current password to
  /// re-derive the old key, and the caller is responsible for
  /// re-encrypting every vault entry with the new key (see
  /// VaultRepository.reencryptAll in a full implementation).
  Future<bool> changeMasterPassword(
      String currentPassword, String newPassword) async {
    final ok = await login(currentPassword);
    if (!ok) return false;

    final newSalt = _encryptionService.generateSalt();
    final newKey = _encryptionService.deriveKey(newPassword, newSalt);
    final newVerifier = _encryptionService.computeVerifier(newKey);

    await _secureStorage.write(key: _kSaltKey, value: base64Encode(newSalt));
    await _secureStorage.write(key: _kVerifierKey, value: newVerifier);
    _sessionKey = newKey;
    await AutofillBridge.instance.pushSessionKey(newKey);
    return true;
  }

  /// Wipes ALL stored auth material (used by "reset app" / forgot password
  /// flows). This does NOT delete vault data — call
  /// DatabaseService.instance.wipeAll() alongside this if you want a full
  /// factory reset.
  Future<void> resetAuth() async {
    await _secureStorage.delete(key: _kSaltKey);
    await _secureStorage.delete(key: _kVerifierKey);
    await _secureStorage.delete(key: _kBiometricWrappedKey);
    await _secureStorage.delete(key: _kBiometricEnabledKey);
    _sessionKey = null;
    AutofillBridge.instance.clearSessionKey();
  }
}
