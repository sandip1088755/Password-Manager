// database_service.dart — local SQLite storage for vault entries.
//
// Note on "encrypted SQLite": the spec mentions SQLCipher. The vanilla
// `sqflite` package used here does NOT encrypt the .db file at rest by
// itself — instead, every sensitive column (password, notes) is already
// AES-256-GCM ciphertext by the time it reaches the database, so the
// content is protected even if the raw file leaked. If you want the
// entire file encrypted too (defense in depth), swap this package for
// `sqflite_sqlcipher` (same API) and set a passphrase in openDatabase();
// that needs a native plugin build step so it's not wired up here.

import 'package:path/path.dart';
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';

import '../models/vault_entry.dart';

class DatabaseService {
  static final DatabaseService instance = DatabaseService._internal();
  DatabaseService._internal();

  Database? _db;

  Future<Database> get database async {
    _db ??= await _initDb();
    return _db!;
  }

  Future<Database> _initDb() async {
    final docsDir = await getApplicationDocumentsDirectory();
    final dbPath = join(docsDir.path, 'vault.db');
    return openDatabase(
      dbPath,
      version: 2,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE vault_entries (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            username TEXT NOT NULL,
            encrypted_password TEXT NOT NULL,
            website TEXT,
            category TEXT,
            encrypted_notes TEXT,
            favorite INTEGER NOT NULL DEFAULT 0,
            entry_type TEXT NOT NULL DEFAULT 'login',
            encrypted_custom_fields TEXT,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
          )
        ''');
        await db.execute(
          'CREATE INDEX idx_vault_category ON vault_entries (category)',
        );
        await db.execute(
          'CREATE INDEX idx_vault_entry_type ON vault_entries (entry_type)',
        );
        await _createFilesTable(db);
      },
      onUpgrade: (db, oldVersion, newVersion) async {
        if (oldVersion < 2) {
          await db.execute(
            "ALTER TABLE vault_entries ADD COLUMN entry_type TEXT NOT NULL DEFAULT 'login'",
          );
          await db.execute(
            'ALTER TABLE vault_entries ADD COLUMN encrypted_custom_fields TEXT',
          );
          await db.execute(
            'CREATE INDEX IF NOT EXISTS idx_vault_entry_type ON vault_entries (entry_type)',
          );
          await _createFilesTable(db);
        }
      },
    );
  }

  Future<void> _createFilesTable(Database db) async {
    await db.execute('''
      CREATE TABLE IF NOT EXISTS secure_files (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        display_name TEXT NOT NULL,
        file_type TEXT NOT NULL,
        encrypted_file_path TEXT NOT NULL,
        size_bytes INTEGER NOT NULL,
        created_at TEXT NOT NULL
      )
    ''');
  }

  Future<int> insertEntry(VaultEntry entry) async {
    final db = await database;
    final map = entry.toMap()..remove('id');
    return db.insert('vault_entries', map);
  }

  Future<int> updateEntry(VaultEntry entry) async {
    final db = await database;
    return db.update(
      'vault_entries',
      entry.toMap(),
      where: 'id = ?',
      whereArgs: [entry.id],
    );
  }

  Future<int> deleteEntry(int id) async {
    final db = await database;
    return db.delete('vault_entries', where: 'id = ?', whereArgs: [id]);
  }

  Future<List<VaultEntry>> getAllEntries() async {
    final db = await database;
    final rows = await db.query('vault_entries', orderBy: 'title ASC');
    return rows.map(VaultEntry.fromMap).toList();
  }

  Future<List<VaultEntry>> searchEntries(String query) async {
    final db = await database;
    final rows = await db.query(
      'vault_entries',
      where: 'title LIKE ? OR username LIKE ? OR website LIKE ?',
      whereArgs: ['%$query%', '%$query%', '%$query%'],
      orderBy: 'title ASC',
    );
    return rows.map(VaultEntry.fromMap).toList();
  }

  Future<void> wipeAll() async {
    final db = await database;
    await db.delete('vault_entries');
  }

  // --- Secure Files (Encrypted File Vault) ---

  Future<int> insertFileRecord({
    required String displayName,
    required String fileType,
    required String encryptedFilePath,
    required int sizeBytes,
  }) async {
    final db = await database;
    return db.insert('secure_files', {
      'display_name': displayName,
      'file_type': fileType,
      'encrypted_file_path': encryptedFilePath,
      'size_bytes': sizeBytes,
      'created_at': DateTime.now().toIso8601String(),
    });
  }

  Future<List<Map<String, Object?>>> getAllFileRecords() async {
    final db = await database;
    return db.query('secure_files', orderBy: 'created_at DESC');
  }

  Future<int> deleteFileRecord(int id) async {
    final db = await database;
    return db.delete('secure_files', where: 'id = ?', whereArgs: [id]);
  }
}
