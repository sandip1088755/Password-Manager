// settings_service.dart — small non-sensitive app preferences.

import 'package:shared_preferences/shared_preferences.dart';

class SettingsService {
  static final SettingsService instance = SettingsService._internal();
  SettingsService._internal();

  static const _kAutoLockMinutesKey = 'auto_lock_minutes';

  /// 0 means "immediately" on background; default 1 minute.
  Future<int> getAutoLockMinutes() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getInt(_kAutoLockMinutesKey) ?? 1;
  }

  Future<void> setAutoLockMinutes(int minutes) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_kAutoLockMinutesKey, minutes);
  }
}
