import 'dart:async';
import 'package:flutter/material.dart';

import 'services/auth_service.dart';
import 'services/settings_service.dart';
import 'services/theme_service.dart';
import 'screens/splash/splash_screen.dart';
import 'screens/vault/login_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const PasswordManagerProApp());
}

class PasswordManagerProApp extends StatefulWidget {
  const PasswordManagerProApp({super.key});

  static _PasswordManagerProAppState? of(BuildContext context) =>
      context.findAncestorStateOfType<_PasswordManagerProAppState>();

  @override
  State<PasswordManagerProApp> createState() => _PasswordManagerProAppState();
}

class _PasswordManagerProAppState extends State<PasswordManagerProApp>
    with WidgetsBindingObserver {
  final GlobalKey<NavigatorState> _navigatorKey = GlobalKey<NavigatorState>();
  Timer? _backgroundTimer;
  Color _seedColor = ThemeService.presets.first.seedColor;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _loadTheme();
  }

  Future<void> _loadTheme() async {
    final id = await ThemeService.instance.getSelectedPresetId();
    final preset = ThemeService.instance.presetById(id);
    if (mounted) setState(() => _seedColor = preset.seedColor);
  }

  /// Called by SettingsScreen right after the user picks a new premium
  /// theme, so it applies instantly without needing an app restart.
  Future<void> refreshTheme() => _loadTheme();

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _backgroundTimer?.cancel();
    super.dispose();
  }

  // Auto-lock: when the app is backgrounded, start a timer for the
  // configured number of minutes. If the app is still backgrounded (or
  // gets killed) when it fires, wipe the in-memory session key so the
  // next resume requires master password / biometrics again.
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (!AuthService.instance.isUnlocked) return;

    if (state == AppLifecycleState.paused ||
        state == AppLifecycleState.inactive) {
      _armAutoLock();
    } else if (state == AppLifecycleState.resumed) {
      _backgroundTimer?.cancel();
    }
  }

  Future<void> _armAutoLock() async {
    _backgroundTimer?.cancel();
    final minutes = await SettingsService.instance.getAutoLockMinutes();
    _backgroundTimer = Timer(Duration(minutes: minutes), () {
      AuthService.instance.lock();
      // Force navigation back to the login screen once the user returns.
      _navigatorKey.currentState?.pushAndRemoveUntil(
        MaterialPageRoute(builder: (_) => const LoginScreen()),
        (route) => false,
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      navigatorKey: _navigatorKey,
      title: 'Password Manager Pro',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorSchemeSeed: _seedColor,
        useMaterial3: true,
        brightness: Brightness.light,
      ),
      darkTheme: ThemeData(
        colorSchemeSeed: _seedColor,
        useMaterial3: true,
        brightness: Brightness.dark,
      ),
      themeMode: ThemeMode.system,
      home: const SplashScreen(),
    );
  }
}
