// vault_entry.dart — a single credential stored in the vault.
//
// Design note: title / username / website / category stay in plaintext so
// the list screen can search & sort without decrypting every row. The
// password and notes — the actually sensitive parts — are always stored
// AES-256-GCM encrypted and only decrypted in memory when the user opens
// the entry. If you need username/website encrypted too for a stricter
// zero-knowledge model, encrypt them the same way and decrypt-all on
// vault unlock instead of lazily.

class VaultEntry {
  final int? id;
  final String title;
  final String username;
  final String encryptedPassword; // base64 ciphertext
  final String website;
  final String category;
  final String encryptedNotes; // base64 ciphertext, may be empty
  final bool favorite;
  final String entryType; // 'login', 'card', 'bank_account', etc.
  final String encryptedCustomFields; // base64 ciphertext of a JSON map
  final DateTime createdAt;
  final DateTime updatedAt;

  VaultEntry({
    this.id,
    required this.title,
    required this.username,
    required this.encryptedPassword,
    this.website = '',
    this.category = 'General',
    this.encryptedNotes = '',
    this.favorite = false,
    this.entryType = 'login',
    this.encryptedCustomFields = '',
    DateTime? createdAt,
    DateTime? updatedAt,
  })  : createdAt = createdAt ?? DateTime.now(),
        updatedAt = updatedAt ?? DateTime.now();

  Map<String, Object?> toMap() => {
        'id': id,
        'title': title,
        'username': username,
        'encrypted_password': encryptedPassword,
        'website': website,
        'category': category,
        'encrypted_notes': encryptedNotes,
        'favorite': favorite ? 1 : 0,
        'entry_type': entryType,
        'encrypted_custom_fields': encryptedCustomFields,
        'created_at': createdAt.toIso8601String(),
        'updated_at': updatedAt.toIso8601String(),
      };

  factory VaultEntry.fromMap(Map<String, Object?> map) => VaultEntry(
        id: map['id'] as int?,
        title: map['title'] as String,
        username: map['username'] as String,
        encryptedPassword: map['encrypted_password'] as String,
        website: (map['website'] as String?) ?? '',
        category: (map['category'] as String?) ?? 'General',
        encryptedNotes: (map['encrypted_notes'] as String?) ?? '',
        favorite: (map['favorite'] as int? ?? 0) == 1,
        entryType: (map['entry_type'] as String?) ?? 'login',
        encryptedCustomFields: (map['encrypted_custom_fields'] as String?) ?? '',
        createdAt: DateTime.parse(map['created_at'] as String),
        updatedAt: DateTime.parse(map['updated_at'] as String),
      );

  VaultEntry copyWith({
    int? id,
    String? title,
    String? username,
    String? encryptedPassword,
    String? website,
    String? category,
    String? encryptedNotes,
    bool? favorite,
    String? entryType,
    String? encryptedCustomFields,
    DateTime? updatedAt,
  }) {
    return VaultEntry(
      id: id ?? this.id,
      title: title ?? this.title,
      username: username ?? this.username,
      encryptedPassword: encryptedPassword ?? this.encryptedPassword,
      website: website ?? this.website,
      category: category ?? this.category,
      encryptedNotes: encryptedNotes ?? this.encryptedNotes,
      favorite: favorite ?? this.favorite,
      entryType: entryType ?? this.entryType,
      encryptedCustomFields: encryptedCustomFields ?? this.encryptedCustomFields,
      createdAt: createdAt,
      updatedAt: updatedAt ?? DateTime.now(),
    );
  }
}
