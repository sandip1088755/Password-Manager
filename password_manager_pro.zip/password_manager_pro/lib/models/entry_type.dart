// entry_type.dart — defines every kind of vault entry and which fields
// it needs. Adding a new type (e.g. "Insurance Policy") later is just
// adding one more entry to this list — the add/edit screen renders
// itself from this schema, no new screen needed.

import 'package:flutter/material.dart';

enum FieldKind { text, multiline, masked, date }

class FieldSchema {
  final String key; // stored as JSON key in encrypted_custom_fields
  final String label;
  final FieldKind kind;
  final bool required;

  const FieldSchema(
    this.key,
    this.label, {
    this.kind = FieldKind.text,
    this.required = false,
  });
}

class EntryTypeDef {
  final String id; // stored in DB "entry_type" column
  final String label;
  final IconData icon;
  final List<FieldSchema> fields;
  final bool hasPassword; // whether this type shows a password field at all

  const EntryTypeDef({
    required this.id,
    required this.label,
    required this.icon,
    required this.fields,
    this.hasPassword = false,
  });
}

class EntryTypes {
  static const login = EntryTypeDef(
    id: 'login',
    label: 'Login',
    icon: Icons.public,
    hasPassword: true,
    fields: [],
  );

  static const card = EntryTypeDef(
    id: 'card',
    label: 'Credit/Debit Card',
    icon: Icons.credit_card,
    fields: [
      FieldSchema('cardholder_name', 'Cardholder Name', required: true),
      FieldSchema('card_number', 'Card Number', kind: FieldKind.masked, required: true),
      FieldSchema('expiry', 'Expiry (MM/YY)', required: true),
      FieldSchema('cvv', 'CVV', kind: FieldKind.masked, required: true),
      FieldSchema('pin', 'ATM PIN', kind: FieldKind.masked),
      FieldSchema('bank_name', 'Bank Name'),
    ],
  );

  static const bankAccount = EntryTypeDef(
    id: 'bank_account',
    label: 'Bank Account',
    icon: Icons.account_balance,
    fields: [
      FieldSchema('bank_name', 'Bank Name', required: true),
      FieldSchema('account_holder', 'Account Holder Name', required: true),
      FieldSchema('account_number', 'Account Number', kind: FieldKind.masked, required: true),
      FieldSchema('ifsc', 'IFSC Code', required: true),
      FieldSchema('branch', 'Branch'),
      FieldSchema('swift', 'SWIFT/IBAN'),
    ],
  );

  static const upi = EntryTypeDef(
    id: 'upi',
    label: 'UPI ID',
    icon: Icons.qr_code_2,
    fields: [
      FieldSchema('upi_id', 'UPI ID', required: true),
      FieldSchema('linked_bank', 'Linked Bank'),
      FieldSchema('upi_pin', 'UPI PIN', kind: FieldKind.masked),
    ],
  );

  static const passport = EntryTypeDef(
    id: 'passport',
    label: 'Passport',
    icon: Icons.flight_takeoff,
    fields: [
      FieldSchema('full_name', 'Full Name', required: true),
      FieldSchema('passport_number', 'Passport Number', kind: FieldKind.masked, required: true),
      FieldSchema('nationality', 'Nationality'),
      FieldSchema('date_of_issue', 'Date of Issue', kind: FieldKind.date),
      FieldSchema('date_of_expiry', 'Date of Expiry', kind: FieldKind.date),
      FieldSchema('place_of_issue', 'Place of Issue'),
    ],
  );

  static const aadhaar = EntryTypeDef(
    id: 'aadhaar',
    label: 'Aadhaar Card',
    icon: Icons.badge,
    fields: [
      FieldSchema('full_name', 'Full Name', required: true),
      FieldSchema('aadhaar_number', 'Aadhaar Number', kind: FieldKind.masked, required: true),
      FieldSchema('date_of_birth', 'Date of Birth', kind: FieldKind.date),
      FieldSchema('address', 'Address', kind: FieldKind.multiline),
    ],
  );

  static const pan = EntryTypeDef(
    id: 'pan',
    label: 'PAN Card',
    icon: Icons.article,
    fields: [
      FieldSchema('full_name', 'Full Name', required: true),
      FieldSchema('pan_number', 'PAN Number', kind: FieldKind.masked, required: true),
      FieldSchema('date_of_birth', 'Date of Birth', kind: FieldKind.date),
    ],
  );

  static const drivingLicense = EntryTypeDef(
    id: 'driving_license',
    label: 'Driving License',
    icon: Icons.motorcycle,
    fields: [
      FieldSchema('full_name', 'Full Name', required: true),
      FieldSchema('license_number', 'License Number', kind: FieldKind.masked, required: true),
      FieldSchema('date_of_issue', 'Date of Issue', kind: FieldKind.date),
      FieldSchema('valid_till', 'Valid Till', kind: FieldKind.date),
      FieldSchema('vehicle_classes', 'Vehicle Classes (e.g. LMV, MCWG)'),
      FieldSchema('issuing_authority', 'Issuing Authority (RTO)'),
    ],
  );

  static const secureNote = EntryTypeDef(
    id: 'secure_note',
    label: 'Secure Note',
    icon: Icons.note_alt,
    fields: [], // uses the existing `notes` rich text field only
  );

  static const List<EntryTypeDef> all = [
    login,
    card,
    bankAccount,
    upi,
    passport,
    aadhaar,
    pan,
    drivingLicense,
    secureNote,
  ];

  static EntryTypeDef byId(String id) =>
      all.firstWhere((t) => t.id == id, orElse: () => login);
}
