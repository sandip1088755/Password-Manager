# Getting an APK via GitHub (no local Flutter install needed)

This project includes `.github/workflows/build-apk.yml` — a GitHub
Actions workflow that builds the APK for you automatically, on GitHub's
servers, every time you push code. You don't need Flutter/Android Studio
installed on your own machine at all.

## Steps

1. **Create a new repo on GitHub** (github.com → New repository), e.g.
   `password-manager-pro`. Keep it Public or Private, either works.

2. **Upload this project** to that repo. Easiest way from your phone/PC:
   - Unzip `password_manager_pro.zip`
   - On the GitHub repo page → "uploading an existing file" → drag the
     whole unzipped folder in, OR
   - If you're comfortable with git:
     ```bash
     cd password_manager_pro
     git init
     git add .
     git commit -m "Initial commit"
     git branch -M main
     git remote add origin https://github.com/<your-username>/password-manager-pro.git
     git push -u origin main
     ```

3. **Go to the "Actions" tab** on your GitHub repo. You'll see "Build APK"
   running automatically (triggered by your push). It takes about 5–8
   minutes.

4. **Download the APK** once it finishes, two ways:
   - **Actions tab → the finished run → Artifacts section** → download
     `password-manager-pro-apk.zip` (contains `app-release.apk`)
   - **Releases** (right sidebar of your repo, or `github.com/<you>/<repo>/releases`)
     → the APK is attached directly there as `app-release.apk`, permanent
     link, easy to share

5. **Install on your phone**: transfer the `.apk` file to your Android
   phone and open it. You'll need to allow "install from unknown sources"
   for whichever app you use to open it (Files app / Chrome / etc.) —
   Android will prompt you for this the first time.

## Notes

- The workflow uses `flutter create --platforms=android .` to generate
  the `android/` folder fresh on GitHub's servers each time — that's
  normal and expected, not an error.
- This builds an **unsigned/debug-keystore release APK**, fine for
  testing on your own device or sharing with testers. Before publishing
  to the Play Store you'll need to generate your own signing key and
  add it to the workflow (I can set that up too when you're ready).
- Every push to `main` creates a new numbered release (Build #1, #2, ...)
  so you always have a history of installable APKs.
