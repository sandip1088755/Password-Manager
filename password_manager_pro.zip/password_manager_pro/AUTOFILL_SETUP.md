# Autofill Setup Guide — "Fill Facebook/Instagram/bank login automatically"

This adds real Android system-wide Autofill: once set up, when you open
Facebook (or any app/website) and tap the login field, Android shows your
saved vault entries as suggestions — tap one and it fills instantly.

## Why this needs a one-time manual step

The GitHub Actions workflow generates the `android/` folder fresh on every
build (`flutter create --platforms=android .`), which would normally
overwrite the custom native files below. So autofill requires **one
one-time change**: commit the `android/` folder to your repo yourself,
and tell the CI workflow to stop regenerating it. Everything below is
already included in this zip — you just need to follow these steps once.

## Step-by-step

### 1. Generate the base Android project (if you haven't already)

```bash
cd password_manager_pro
flutter create --platforms=android .
```

This creates `android/app/src/main/kotlin/com/example/password_manager_pro/`
with a default `MainActivity.kt`, plus `AndroidManifest.xml`, `build.gradle`,
etc. **The zip already contains a custom `MainActivity.kt`,
`VaultAutofillService.kt`, and `autofill_service_config.xml` under
`android/`** — after running `flutter create`, do NOT let it overwrite
those three files. If prompted about overwriting, keep the ones from this
zip (they contain the autofill wiring); accept overwrites for everything
else (gradle wrapper, default resources, etc).

### 2. Add the security-crypto dependency

Open `android/app/build.gradle` and add this inside the `dependencies { }`
block:

```gradle
dependencies {
    implementation "androidx.security:security-crypto:1.1.0-alpha06"
}
```

### 3. Set minimum SDK version

Still in `android/app/build.gradle`, make sure:

```gradle
android {
    defaultConfig {
        minSdkVersion 26   // Autofill framework requires API 26 (Android 8.0)
    }
}
```

### 4. Edit `android/app/src/main/AndroidManifest.xml`

Add the permission near the top, inside `<manifest>` but before
`<application>`:

```xml
<uses-permission android:name="android.permission.USE_BIOMETRIC" />
```

Then add the service declaration **inside** `<application>...</application>`,
alongside the existing `<activity>` tag:

```xml
<service
    android:name=".VaultAutofillService"
    android:label="Password Manager Pro"
    android:permission="android.permission.BIND_AUTOFILL_SERVICE"
    android:exported="true">
    <intent-filter>
        <action android:name="android.service.autofill.AutofillService" />
    </intent-filter>
    <meta-data
        android:name="android.autofill"
        android:resource="@xml/autofill_service_config" />
</service>
```

### 5. Commit the android/ folder to your GitHub repo

```bash
git add android/
git commit -m "Add Android platform folder + autofill service"
git push
```

### 6. Update `.github/workflows/build-apk.yml`

Change the "Generate platform folders" step so it only runs if `android/`
doesn't already exist (otherwise CI would overwrite your custom files
every single build):

```yaml
      - name: Generate platform folders (only if missing)
        run: |
          if [ ! -d "android" ]; then
            flutter create --platforms=android .
          fi
```

Commit that change too, then push. The next CI build will use your
committed `android/` folder as-is, autofill service included.

### 7. On your phone, after installing the APK

1. Open Password Manager Pro, set your master password, add a Facebook
   entry (title "Facebook", your username, your password)
2. Go to Settings inside the app → tap **"Autofill (fill FB/Insta/bank
   logins)"** → Android's system settings opens → select "Password
   Manager Pro" as your autofill service → confirm
3. Open the Facebook app, tap the password field — you should see your
   saved entry suggested. Tap it to fill.

## How matching works (and its limits)

- The service reads the app's package name (e.g. `com.facebook.katana`)
  or the web domain (for Chrome/WebView logins) and matches it against
  your entry's **title** or **website** field using a simple keyword
  match. So for reliable autofill, name your entries clearly — "Facebook"
  for the Facebook app, "facebook.com" if you also log in via browser.
- Autofill only works **while the vault is unlocked** in the Flutter app
  (matches the rest of the app's security model) — lock the vault and
  autofill suggestions stop appearing until you unlock again.
- This is a genuine, functional implementation, but Autofill behavior
  varies across OEM Android skins (Samsung, Xiaomi, etc. sometimes add
  their own restrictions) — test on your actual target devices before
  relying on it for a Play Store release.
