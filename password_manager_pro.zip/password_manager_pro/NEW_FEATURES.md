# New Features — Identity Vault, Secure Files, QR Sharing, Premium Themes

## What's new in this update

1. **Identity & Payment Vault** — Card, Bank Account, UPI, Passport,
   Aadhaar, PAN, Driving License are now first-class entry types (tap the
   **+** button → pick a type). Each renders its own relevant fields
   (card number, CVV, IFSC, passport number, etc.), all AES-256-GCM
   encrypted, same as passwords.
2. **Secure Notes** — now its own entry type (was previously just a notes
   field on logins; still available either way).
3. **Encrypted File Vault** ("Secure Photos / Documents") — tap the
   folder icon in the vault's app bar → **Add File** → pick a photo, PDF,
   or document. It's encrypted with the same AES-256-GCM key and stored
   privately; nothing is ever written to shared/public storage.
4. **QR Code Password Sharing** — open any login entry → tap the QR icon
   in the top bar → show the code to someone in person → they tap the
   scan icon (bottom-left FAB on the vault home screen) → confirm import.
   No server involved; the code expires 5 minutes after generation.
5. **Premium Themes** — Settings → pick from 6 curated Material 3 color
   presets, applies instantly. (Not gated behind a paywall yet — that
   needs Google Play Billing integration, a separate piece of work when
   you're ready to monetize themes.)

## One new required permission (for QR scanning)

Add this to `android/app/src/main/AndroidManifest.xml`, alongside the
`USE_BIOMETRIC` permission from `AUTOFILL_SETUP.md`:

```xml
<uses-permission android:name="android.permission.CAMERA" />
```

File picking (`file_picker` package) needs no extra manifest permission
on modern Android (API 29+) — it uses the system's Storage Access
Framework, which doesn't require broad storage permissions.

## Database migration note

The vault database automatically upgrades itself (version 1 → 2) the
first time you open the app after this update — existing entries keep
working, new columns (`entry_type`, `encrypted_custom_fields`) default
to `'login'` / empty so nothing breaks for data created before this
update.

## Honest limits of QR sharing

The QR code is not additionally encrypted beyond what it takes to be
scanned — the security model is **physical proximity** (you show your
screen, they point their camera at it), not cryptography. Anyone who
photographs or screen-records the code within its 5-minute window can
read the password. This is the same trust model Bitwarden/1Password's
similar "send" features rely on for local transfer; it's appropriate
for handing a Wi-Fi password to a guest or a login to a family member
in person — not for anything you'd post publicly.
