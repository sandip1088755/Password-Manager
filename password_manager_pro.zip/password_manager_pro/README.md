# Password Manager Pro — MVP Core

A real, working, offline-first password vault built in Flutter (Material 3).
Every screen and every crypto call in this bundle is functional code — no
mocked data, no fake buttons.

## What's actually implemented (fully working)

- **Master password setup + login** — PBKDF2-HMAC-SHA256 (100k iterations)
  key derivation, zero-knowledge (password itself is never stored)
- **AES-256-GCM encryption** for every password and note field
- **Local encrypted vault** (SQLite) — add / edit / delete / search entries,
  categories, favorites
- **Password generator** — Password / Passphrase / PIN modes, strength
  meter, entropy calculator, secure random generation
- **Biometric unlock** (fingerprint/face) as an alternative to typing the
  master password
- **Auto-lock timer** — configurable (immediate / 1 / 2 / 5 / 10 min),
  triggers on app backgrounding
- **Change master password** flow
- **Material 3** UI, light/dark theme
- **Android Autofill Service** — fills saved logins system-wide (Facebook,
  Instagram, banking apps, Chrome, etc). This one needs a short one-time
  manual step because of how Android native code + CI interact — see
  **`AUTOFILL_SETUP.md`** for exact instructions (already includes the
  Kotlin service, manifest snippet, and gradle changes — just needs you
  to run `flutter create` once and commit the result).

## What is NOT in this bundle (and why)

These need infrastructure or native platform setup that only you can do in
your own accounts/projects — I can help write the code for any of these
next, but they can't ship "pre-wired" the way the vault core can:

| Feature | Why it's separate |
|---|---|
| Cloud sync / multi-device | Needs a Firebase project (your own API keys, Firestore rules) |
| Import from Chrome/Bitwarden/LastPass/etc. | Each has a different export format; needs per-format parsers |
| AI Security Advisor / AI features | Needs an LLM API key + backend or on-device model |
| Full-disk SQLCipher encryption | Requires swapping to `sqflite_sqlcipher` and a native build step |
| Root/emulator/screenshot detection | Native platform channel code, differs per Android version |
| Payment/Identity vault UI, file encryption, secure sharing, emergency access | Straightforward to add as more screens on top of this same architecture — just tell me which one next |

## Setup

```bash
# 1. Create the platform folders (android/, ios/) — this bundle only ships
#    the Dart/Flutter side, since platform folders are huge and
#    machine-generated:
cd password_manager_pro
flutter create --platforms=android,ios .

# 2. Get dependencies
flutter pub get

# 3. Run
flutter run
```

### Required native permissions

**Android** — add to `android/app/src/main/AndroidManifest.xml` (inside
`<manifest>`, before `<application>`):

```xml
<uses-permission android:name="android.permission.USE_BIOMETRIC" />
```

And in `android/app/build.gradle`, make sure `minSdkVersion` is at least
23 (required by `local_auth`).

**iOS** — add to `ios/Runner/Info.plist`:

```xml
<key>NSFaceIDUsageDescription</key>
<string>Unlock your vault with Face ID</string>
```

## Project structure

```
lib/
  core/
    encryption_service.dart      # PBKDF2 + AES-256-GCM
  models/
    vault_entry.dart             # DB row model
  services/
    auth_service.dart            # master password, session key, biometrics
    database_service.dart        # SQLite CRUD
    vault_repository.dart        # plaintext-facing API screens use
    settings_service.dart        # auto-lock preference
  screens/
    splash/splash_screen.dart
    onboarding/create_master_password_screen.dart
    vault/login_screen.dart
    vault/vault_home_screen.dart
    vault/add_edit_entry_screen.dart
    generator/password_generator_screen.dart
    settings/settings_screen.dart
  main.dart                      # app root + auto-lock lifecycle observer
```

## Security notes (please read before shipping)

- This is a solid MVP architecture, but it has **not been audited**. Get a
  real security review before storing anyone's real banking/identity data.
- The master password is never stored — only a salt + a keyed-hash
  verifier. If a user forgets it, their vault is unrecoverable by design
  (this is correct zero-knowledge behavior, but make sure your onboarding
  UI warns users clearly, which it currently does).
- Title/username/website are stored in plaintext in the local DB so the
  list screen can search without decrypting every row; password and notes
  are always ciphertext. If you want everything encrypted (stricter
  zero-knowledge), say so and I'll switch the repository to decrypt-all-
  on-unlock instead of lazy per-field decryption.
